Owned float originals and derived tiles, 2026-10-27.

manifest.json maps logical paths to sizes/SHA256; unique bytes are in objects/.
extract-evidence.py restores the logical files. source/ and raw/final-source.patch
reconstruct every changed file against baseCommit. release/ is the complete frozen
production build, including 39 guides and actual preparation/read workers.
raw/ retains build/unit/source/full-production reports, original type-check
corrections, pilots, resource relocation receipt, fixed source/release identities
and final observed audit. browser/ retains real files, original-bearing projects,
independent numerical comparisons, cache corruption/cancellation/quota/worker
failure and owner persistence evidence, screenshots and the actual 50 MP output.
reference/ retains original float TIFFs, native CMM/libtiff/profile bytes,
independent float references, generator fingerprints, provenance and licenses.

The 10000x5000 original is admitted without a bitmap or byte editing proxy.
3880 losslessly compressed float32 tiles at up to 256x52 are prepared from actual
original samples through native ICC, verified and atomically published to IDB.
395 bounded read windows stream to actual float32 BigTIFF. An independent native
libtiff reader checks every one of 200000000 float samples against separately
generated native Linux CMM references, including complete ICC and exact decoded
hash. This is source-storage correctness, not float document editing. Small cases
cover twelve byte-order/compression/predictor/planar/color/alpha source layouts.
Compiled production workers match their independent sample hashes without dev
access. Existing native project/workspace originals reconstruct the same cache.

No original resolution cap or destructive downsampling is introduced. Working
buffer limits, compressed/hash validation, decoded LRU and cancellation are
separate from native geometry. Storage quota, full native row/decompression,
WASM/browser process resources remain actual limits. No peak process-memory,
sustained 60fps, physical photographic quality, general HDR or device acceptance
is inferred. The first broad source matrix passes 131 cases; after reproducing and
correcting malformed manifest repair, a fresh build, all 2634 unit/API checks,
12 focused source cases and the complete 162 production cases pass. Initial and
corrected results remain separate, covering 132 distinct affected source cases.
The cache is disposable original-derived data, never the only owner
of authored float edits. Public documents/rendering/tools/history remain sRGB8.
Actual float model/commands/scene/effects/masks/tools/display/persistence/Undo/
recovery/automation/delivery and every unfinished original roadmap gate remain
required. Goal status stays active.
