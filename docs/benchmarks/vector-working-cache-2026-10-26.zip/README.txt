F14 compact vector working/cache pixels, 2026-10-26.
Final source reconstructs exactly from 62a5b778de3d4fa0fdb7e912131a8b47f7208535 using raw/canoli-vector-final-source.patch.
Only final 150-native and 152-production reports are acceptance; pilots and earlier harness versions are diagnostic.
Use verified-1..3 for 288 paced matching-pixel timings per variant, harnessVersion 3. Overlay samples are absent, so no overlay latency claim. No physical compositor, sustained 60fps, GPU/device-wide or full-roadmap claim.
Independent Pillow/container readers check full 50 MP exports, original bytes and complete dense workflows.
