from pathlib import Path
root=Path('/home/kestrel/projects/luma-editor')
replacements={
 'docs/API.md': [('"schemaVersion": 21,','"schemaVersion": 22,')],
 'docs/ARCHITECTURE.md': [
  ('current model validation accepts schemas 1–21.','current model validation accepts schemas 1–22.'),
  ('Existing schema 21/project 3/workspace 2 selection storage','Existing schema 22/project 3/workspace 2 selection storage'),
  ('so schema 21/project 3/workspace 2 are unchanged.','so schema 22/project 3/workspace 2 are unchanged.'),
 ],
 'docs/SCRIPTING_API.md': [
  ('Document schema 21/project 3/workspace 2 remain unchanged.','Document schema 22/project 3/workspace 2 remain unchanged.'),
  ('(current document 21, project 3, workspace 2)','(current document 22, project 3, workspace 2)'),
  ('Results reuse existing selection data in document schema 21/project 3/workspace 2.','Results reuse existing selection data in document schema 22/project 3/workspace 2.'),
  ('Document schema 21/project 3/workspace 2, masks,','Document schema 22/project 3/workspace 2, masks,'),
 ],
}
for path,pairs in replacements.items():
 p=root/path;s=p.read_text()
 for old,new in pairs:
  assert s.count(old)==1,(path,old,s.count(old));s=s.replace(old,new)
 p.write_text(s)
