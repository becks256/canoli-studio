import json, hashlib, struct, sys, copy, math
from pathlib import Path
from PIL import Image, ImageChops

ROOT=Path('/home/kestrel/projects/luma-editor')
def project(path):
    data=path.read_bytes(); assert data[:4]==b'LUMA' and data[4] in b'345'
    size=struct.unpack_from('<Q',data,8)[0]; raw=data[48:48+size]
    assert hashlib.sha256(raw).digest()==data[16:48]
    value=json.loads(raw)
    for asset in value['assets']:
        payload=data[48+size+asset['offset']:48+size+asset['offset']+asset['size']]
        assert hashlib.sha256(payload).hexdigest()==asset['sha256']
        if path.name=='vector-cache-50mp.luma' and asset['width']==10000:
            assert payload==(ROOT/'tests/fixtures/raw/native-50mp.png').read_bytes()
    return value

def exact(a,b):
    with Image.open(a) as x,Image.open(b) as y:
        assert x.size==y.size,(a,b)
        assert all(v==(0,0) for v in ImageChops.difference(x.convert('RGBA'),y.convert('RGBA')).getextrema()),(a,b)

results={'runs':[],'projects':0,'native50mpExports':0,'denseWorkflows':0}
for arg in sys.argv[1:]:
    root=Path(arg)
    for file in root.rglob('vector-cache-*.luma'):
        project(file); results['projects']+=1
    for file in root.rglob('vector-cache-50mp.png'):
        with Image.open(ROOT/'tests/fixtures/raw/native-50mp.png') as original,Image.open(file) as actual:
            reference=original.convert('RGBA'); assert reference.size==(10000,5000)==actual.size
            reference.paste((36,104,172,255),(2016,2024,2216,2624))
            assert all(v==(0,0) for v in ImageChops.difference(reference,actual.convert('RGBA')).getextrema())
        results['native50mpExports']+=1
    for file in root.rglob('vector-cache-workflow.json'):
        d=file.parent; source=project(d/'vector-cache-source.luma')['document']
        assert project(d/'vector-cache-before.luma')['document']==source
        assert project(d/'vector-cache-undo.luma')['document']==source
        moved=copy.deepcopy(source); target=next(c for c in moved['children'] if c['name']=='Measured target')
        assert (target['x'],target['y'])==(250,225);target.update(x=266,y=231)
        assert project(d/'vector-cache-after.luma')['document']==moved
        assert sum(len(c['paths']) for c in source['children'])==2216
        for other in ['reference','redo','reopened']:exact(d/'vector-cache-after.png',d/f'vector-cache-{other}.png')
        exact(d/'vector-cache-before.png',d/'vector-cache-undo.png')
        results['denseWorkflows']+=1

def stats(values):
    values=sorted(values)
    if not values:return {'samples':0,'median':None,'p95':None,'maximum':None}
    return {'samples':len(values),'median':values[len(values)//2],'p95':values[math.ceil(.95*len(values))-1],'maximum':values[-1]}
for variant in ['baseline','candidate']:
    frames=[]; tasks=[]; overlays=[]
    for i in range(1,4):
        prefix=Path(f'/tmp/canoli-drag-{variant}-verified-{i}')
        v=json.loads(prefix.with_suffix('.json').read_text())
        assert v['harnessVersion']==3 and v['sourcePreserved'] and v['normalProduction'] and v['backend']=='canvas2d'
        assert [b['enabled'] for b in v['blocks']]==[False,True,True,False]
        for b in v['blocks']:
            assert len(b['frames'])==24
            assert len({f['sequence'] for f in b['frames']})==24
            assert all(f['foreground']==400 and f['ms']>=f['submittedMs'] for f in b['frames'])
            assert all(b['blockStart']<=t['start']<=b['blockEnd'] for t in b['longTasks'])
            frames += [f['ms'] for f in b['frames']];tasks += b['longTasks'];overlays +=[o['ms'] for o in b['overlays']]
        exact(str(prefix)+'-before.png',str(prefix)+'-cancelled.png')
        exact(str(prefix)+'-before.png','/tmp/canoli-drag-baseline-verified-1-before.png')
    results['runs'].append({'variant':variant,'matchingPixelsMs':stats(frames),'overlayMs':stats(overlays),'longTasks':len(tasks)})
for mode in ['paint5','text-shadow','vector512','vector-static']:
    for variant in ['baseline','candidate']:
        prefix=Path(f'/tmp/canoli-drag-{variant}-{mode}')
        v=json.loads(prefix.with_suffix('.json').read_text()); assert v['harnessVersion']==3
        exact(str(prefix)+'-before.png',str(prefix)+'-cancelled.png')
        exact(str(prefix)+'-before.png',f'/tmp/canoli-drag-baseline-{mode}-before.png')
        frames=[f['ms'] for b in v['blocks'] for f in b['frames']]
        results['runs'].append({'variant':variant,'control':mode,'matchingPixelsMs':stats(frames),'longTasks':sum(len(b['longTasks']) for b in v['blocks'])})
print(json.dumps(results,indent=2))
