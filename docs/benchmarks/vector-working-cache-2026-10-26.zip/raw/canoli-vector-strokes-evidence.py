from pathlib import Path
import hashlib,json,re,datetime,subprocess
from collections import Counter
root=Path('/home/kestrel/projects/luma-editor')
def digest(p):
 p=Path(p);return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
files=['package.json','package-lock.json','src/core/vector-stroke.ts','src/core/drawing.ts','src/core/model.ts','src/core/validation.ts','src/core/commands.ts','src/core/store.ts','src/core/shapes.ts','src/core/affine.ts','src/core/svg-path.ts','src/core/svg-path-import.ts','src/core/svg-import.ts','src/core/svg-export.ts','src/core/assets.ts','src/core/project.ts','src/dom/index.ts','src/tools.ts','src/editor.ts','src/engine/drawing.ts','src/engine/renderer.ts','src/engine/cache.ts','src/engine/export.ts','src/engine/gpu/renderer.ts','src/engine/png.ts','src/engine/svg-import.ts','src/engine/svg-import.worker.ts','src/ui/ToolOptions.tsx','src/ui/VectorStrokeControls.tsx','src/ui/controls.tsx','src/ui/styles.css','src/generated/script-runtime.js','src/scripting/runtime.ts','src/ai/recipes/recorder.ts','server/app.ts','public/wasm/pixels.wasm','assembly/pixels.ts','README.md','docs/PRODUCT_BRIEF.md','docs/REQUIREMENTS.md','docs/ARCHITECTURE.md','docs/API.md','docs/SCRIPTING_API.md','docs/DESIGN_SYSTEM.md','docs/PLUGINS.md','docs/SYSTEM_DESIGN.md','docs/STORAGE_FORMAT.md','docs/FEATURE_STRATEGY.md','docs/IMPLEMENTATION_ROADMAP.md','tests/vector-strokes.test.ts','tests/vector-strokes.e2e.ts','tests/api.test.ts','tests/seo.test.ts','tests/svg-import.test.ts','tests/svg-import-pixels.ts','tests/affine-render.e2e.ts','tests/webgpu.e2e.ts','tests/production.e2e.ts','tests/editor.e2e.ts','tests/vector-construction-latency.e2e.ts','playwright.config.ts','playwright.production.config.ts']
files += [str(p.relative_to(root)) for p in sorted(root.glob('tests/svg-*.e2e.ts')) if str(p.relative_to(root)) not in files]
files += ['node_modules/@xmldom/xmldom/'+p for p in ['package.json','lib/dom-parser.js','lib/sax.js','lib/dom.js']]
unit=Path('/tmp/canoli-vector-strokes-unit-final.log').read_text();browser=Path('/tmp/canoli-vector-strokes-browser-final.log').read_text();production=Path('/tmp/canoli-vector-strokes-production-final.log').read_text()
assert re.search(r'Tests\s+989 passed',unit)
assert re.search(r'Test Files\s+133 passed',unit)
assert re.search(r'322 passed',browser),browser[-1000:]
assert re.search(r'36 passed',production),production[-1000:]
assert not re.search(r'\d+ failed',browser+production)
assert '✓ built' in Path('/tmp/canoli-vector-strokes-build-final.log').read_text()
assert re.search(r'Tests\s+5 passed',Path('/tmp/canoli-vector-strokes-seo-final.log').read_text())
assert Path('/tmp/canoli-vector-strokes-types-final.log').read_text()==''
assert Path('/tmp/canoli-vector-strokes-diff-final.log').read_text()==''
assert len(re.findall(r'✓\s+\d+ tests/vector-strokes\.e2e\.ts:',browser))==21
assert len(re.findall(r'✓\s+\d+ tests/webgpu\.e2e\.ts:',browser))==17
modes=['butt','round','square','square-diagonal','bevel','miter','miter-low','dash-even','dash-odd','dash-zero','dash-zero-gap','dash-negative-offset','dash-positive-offset','curve-dash','closed-dash','affine','reset']
reportNames=[f'canoli-vector-stroke-{mode}.json' for mode in modes]+['canoli-vector-stroke-ui.json','canoli-vector-stroke-50mp.json','canoli-vector-stroke-gpu.json','canoli-vector-stroke-production.json','canoli-vector-stroke-zero-caps.json','canoli-vector-stroke-point-roundtrip.json']
reports={name:json.loads((Path('/tmp')/name).read_text()) for name in reportNames}
zeros=reports['canoli-vector-stroke-zero-caps.json'];assert len(zeros)==85
historicalNames=['canoli-vector-stroke-edge-diagnostic.json','canoli-vector-stroke-gpu-initial.json','canoli-vector-stroke-zero-caps-initial.json']
historical={name:json.loads((Path('/tmp')/name).read_text()) for name in historicalNames}
logs={}
for p in sorted(Path('/tmp').glob('canoli-vector-strokes-*.log')):
 logs[str(p)]={**digest(p),'tail':p.read_text(errors='replace').splitlines()[-15:]}
ordinary=[reports[f'canoli-vector-stroke-{mode}.json'] for mode in modes]
for r in ordinary:assert r['reopened'] and r['roundtrip'] and r['editable']
zeroCases=[r for r in zeros if not r.get('extreme')]
data={
 'schemaVersion':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'F07/F11 editable native vector stroke styles and SVG stroke import/export; full professional-editor roadmap remains active and incomplete',
 'environment':json.loads(Path('/tmp/canoli-vector-strokes-environment.json').read_text()),
 'versions':{'document':22,'projectContainer':3,'workspaceSnapshot':2,'legacyNativeDefaults':['round','round',4,[],0],'svgDefaults':['butt','miter',4,[],0]},
 'implementation':{
  'styles':'Optional cap/join/miter/dash-array/dash-offset records; defensive dash ownership, strict shared path schemas, commands/locks/revisions/undo; OO constructors/setters and all shape factories',
  'migration':'Valid v1-v21 documents/history upgrade without injecting fields; earlier schema labels containing new fields reject, including frozen validated entries',
  'ui':'Native inspector controls, validated explicit dash draft Apply/Enter/Escape, Solid action and ancestor-lock/busy behavior',
  'rendering':'Complete per-path Canvas state, native lines for exact straight segments, conservative square/miter bounds; mask tracing retains its prior cubic coverage',
  'zeroLength':'Explicit zero segments/solid closed contours render round circles or centered squares; move-only/butt points are empty. Half-open dash phase retains zero-sized on-dashes. Closed zero contours with non-solid patterns remain empty, following measured browser behavior',
  'svg':'Validated literal attributes; inert-worker inherited cap/join/miter/absolute-unit dashes and offsets become native editable records. Unsupported relative/pathLength/non-scaling/SVG2 extended joins use explicit flatten fallback',
  'gpu':'Existing native vector reference uploads, style-aware cache invalidation and premultiplied diagnostic readback; no hardware presentation or speedup claim',
  'isolation':'No new script/plugin privileges, install-time execution, external file/network access or REST/browser synchronization',
  'recipes':'Existing layer-add templates retain styled paths; standalone path-update recording remains explicitly unsupported',
 },
 'verification':{
  'build':{'command':'npm run build','result':'actual WASM/runtime/developer-doc generation, TypeScript and production bundling passed'},
  'unit':{'command':'npm test -- --maxWorkers=2','passed':989,'files':133,'newStrokeInvariantTests':8,'newRestCases':1},
  'development':{'command':'npx playwright test tests/svg- tests/vector-strokes.e2e.ts tests/webgpu.e2e.ts tests/affine-render.e2e.ts tests/editor.e2e.ts tests/adjustments.e2e.ts tests/gradient-map.e2e.ts tests/chromatic-adjustments.e2e.ts tests/recipes.e2e.ts tests/foundation-increments.e2e.ts tests/tools.e2e.ts tests/vector-construction-latency.e2e.ts','passed':322,'casesByFile':dict(Counter(re.findall(r'✓\s+\d+ (tests/[^:]+):',browser))),'newVectorStrokeCases':21,'softwareGpuFileCases':17},
  'production':{'command':'npm run test:production','passed':36,'newWorkflow':'Verbatim documented stroke example through real isolated Scripts, native inspector, downloaded SVG/PNG pixels, whole-script and individual edit undo, and editable SVG reimport without developer globals'},
  'seo':{'command':'npx vitest run tests/seo.test.ts','passed':5},
  'typecheck':'npx tsc -b passed','gitDiffCheck':'passed','selectedDistinctBrowserCases':358,
 },
 'ordinaryStrokeComparisons':{'fixtures':len(ordinary),'byteExactFixtures':[r['mode'] for r in ordinary if r['max']==0],'maxRawRgbaDifference':max(r['max'] for r in ordinary),'maxAlphaDifference':max(r['maxAlpha'] for r in ordinary),'maxPremultipliedRgbDifference':max(r['maxPremult'] for r in ordinary),'maxAreaError':max(r['areaError'] for r in ordinary),'maxCentroidErrorPx':max(r['centroidError'] for r in ordinary),'allNativePngAfterSvgReimportByteExact':all(r['roundtrip'] for r in ordinary),'allProjectJsonReopensExact':all(r['reopened'] for r in ordinary)},
 'zeroLengthComparisons':{'variants':len(zeroCases),'extremeMiterCases':1,'maxAlphaDifference':max(r['alpha'] for r in zeroCases),'maxPremultipliedRgbDifference':max(r['premult'] for r in zeroCases),'explanation':'Browser SVG dashed butt points can have max alpha 5 despite ideal empty geometry; native butt stays empty. Round dash-on point edges differ by max alpha 12. Geometry/interior/contour checks and affine editable round trips retained independently. These viewer residuals are not erased by broad byte-parity claims.'},
 'observations50MP':reports['canoli-vector-stroke-50mp.json'],
 'limitations':[
  'F07/F11 and the full roadmap remain incomplete: Boolean/gradient fills, richer vector/type/font editing, broader SVG CSS/type/effect/graph/identity support, PSB/TIFF/PDF/AVIF and remaining professional, AI, workflow and commercial work remain.',
  'Ordinary curve/diagonal/affine fixtures retain antialiasing differences; exact decoded-pixel parity is established only for specifically listed fixtures and native export/reimport checks, not universal SVG viewer equivalence.',
  'Degenerate dash boundaries follow measured Chromium behavior. Faint dashed butt coverage and round edges differ; closed non-solid zero contours remain empty. Not proof of universal SVG2 implementation identity.',
  'Software-adapter diagnostic readback is premultiplied RGBA8; native PNG/Canvas pixels are straight RGBA8. Hardware GPU presentation and physical devices remain unverified.',
  'Observed 50 MP time is one local run, not p95/input-to-photon/long-task/peak-memory/device-independent speed or a controlled performance comparison. Resident sources, browser precision, native decode and output allocations impose real limits; no arbitrary MP/file-size import cutoff.',
  'Recipe standalone path-update recording remains unsupported. No provider evaluation or paid inference, credential/account/cloud transfer or new plugin privilege is introduced.',
 ],
 'validationStages':[
  'Initial strict straight dash comparisons exposed native cubic-vs-line rasterization differences. Geometrically straight vector segments now use native lines; mask curve tracing remains unchanged. Eleven ordinary axis/dash fixtures are byte-exact after the correction.',
  'Inspector duplicate React key from its sibling slider was fixed with a distinct component key and console/page-error assertions.',
  'Optional GPU readPixels required an explicit capability guard for TypeScript.',
  'First new GPU comparison double-premultiplied diagnostic readback. Corrected the reference conversion; raw alpha and premultiplied residuals are retained. Added visible round/square point coverage to the final upload/invalidation case.',
  'An earlier broad run was intentionally stopped after 281 passes with one interrupted and 38 unrun, to fix actual missing native round/square zero-length artwork. It is not counted as completed final validation.',
  'Initial zero-cap tests assumed exact coverage at all SVG boundaries. Measured faint dashed butt epsilon pixels, round edge differences, half-open dash intervals and closed non-solid emptiness; implemented actual cap geometry/dash phase with explicit viewer residuals. Expanded final zero cases to 84 variants plus extreme miter metadata.',
  'Final focused zero cap, affine editable point roundtrip, software GPU, full unit, full selected development and full production checks pass. The roadmap remains active and incomplete.',
 ],
 'primaryReferences':['https://www.w3.org/TR/SVG2/painting.html#StrokeProperties','https://www.w3.org/TR/SVG2/painting.html#StrokeDashing','https://html.spec.whatwg.org/multipage/canvas.html#line-styles'],
 'priorEvidence':json.loads(Path('/tmp/canoli-vector-strokes-prior-evidence.json').read_text()),
 'proseOnlyRefreshRuntimeProof':json.loads(Path('/tmp/canoli-vector-strokes-docs-runtime-proof.json').read_text()),
 'sourceHashes':{p:digest(root/p) for p in files},
 'builtHashes':{str(p.relative_to(root)):digest(p) for p in sorted((root/'dist').rglob('*')) if p.is_file()},
 'reports':reports,'historicalDiagnostics':historical,'logs':logs,
}
out=root/'docs/benchmarks/vector-strokes-2026-10-16.json'
assert not out.exists(),'Evidence already sealed; do not overwrite a prior snapshot.'
out.write_text(json.dumps(data,indent=2)+'\n');print(out, len(data['sourceHashes']),'source hashes',len(reports),'reports')
