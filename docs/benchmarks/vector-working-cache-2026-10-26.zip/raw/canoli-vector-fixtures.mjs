import {Document,VectorLayer,VectorPath,TextLayer} from '/home/kestrel/projects/luma-editor/src/dom/index.ts';
import {serializeProject} from '/home/kestrel/projects/luma-editor/src/core/project.ts';
import {writeFile,mkdir} from 'node:fs/promises';
const cases=[{id:'paths-20',paths:20,layers:1},{id:'paths-200',paths:200,layers:1},{id:'paths-1000',paths:1000,layers:1},{id:'paths-200-layers-64',paths:200,layers:64},{id:'curves-200',paths:200,layers:1,anchors:100}];
const directory='/tmp/canoli-vector-fixtures';await mkdir(directory,{recursive:true});
for(const fixture of cases){
 const doc=new Document({width:800,height:600,name:fixture.id});
 for(let i=1;i<fixture.layers;i++)doc.layers.add(new TextLayer({text:'Background '+i,fontSize:16,x:i%10*70,y:Math.floor(i/10)*50}));
 const layer=new VectorLayer({name:'Moving vectors'});
 for(let i=0;i<fixture.paths;i++){
  const x=20+i%40*18,y=20+Math.floor(i/40)*18;
  const count=fixture.anchors;
  const points=count?Array.from({length:count},(_,j)=>{const a=-Math.PI*.75+Math.PI*2*j/count,r=j%2?7:Math.sqrt(72),px=j===0?x:x+6+Math.cos(a)*r,py=j===0?y:y+6+Math.sin(a)*r;return {x:px,y:py,in:{x:px+Math.sin(a)*.2,y:py-Math.cos(a)*.2},out:{x:px-Math.sin(a)*.2,y:py+Math.cos(a)*.2}};}):[{x,y},{x:x+12,y},{x:x+12,y:y+12},{x,y:y+12}];
  layer.paths.add(new VectorPath({points,closed:true,fill:i===0?'#f01122':'#df2020',stroke:null}));
 }
 doc.layers.add(layer);
 const blob=await serializeProject(doc.toJSON(),{get(){throw new Error('Unexpected raster dependency');}});
 await writeFile(directory+'/'+fixture.id+'.luma',new Uint8Array(await blob.arrayBuffer()));
 console.log(fixture.id,blob.size);
}
