from pathlib import Path
import subprocess,os,json,sys
modes=json.loads(sys.argv[1])if len(sys.argv)>1 else [['baseline-1','http://127.0.0.1:4188'],['candidate-1','http://127.0.0.1:4189'],['candidate-2','http://127.0.0.1:4189'],['baseline-2','http://127.0.0.1:4188'],['baseline-3','http://127.0.0.1:4188'],['candidate-3','http://127.0.0.1:4189']]
for label,url in modes:
 with Path('/tmp/canoli-drag-'+label+'.log').open('w')as log:
  result=subprocess.run(['node','--import','tsx','/tmp/canoli-drag-profile.mjs',label,url,'64','vector200'],stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:print(label,'failed',result.returncode);sys.exit(result.returncode)
 r=json.loads(Path('/tmp/canoli-drag-'+label+'.json').read_text());summary=[]
 for block in r['blocks']:
  values=sorted(f['ms']for f in block['frames']);assert len(values)==24;summary.append({'guides':block['enabled'],'p95':values[22],'longTasks':len(block['longTasks'])})
 print(label,json.dumps(summary),flush=True)
