import hashlib,json,struct,sys
from pathlib import Path
from PIL import Image,ImageChops
import PIL
root=Path(sys.argv[1]);assert root.is_dir();report={'Pillow':PIL.__version__,'pixels':[],'projects':[]}
sha=lambda data:hashlib.sha256(data).hexdigest()
def project(path):
 with path.open('rb')as file:
  header=file.read(48);length=struct.unpack_from('<Q',header,8)[0];raw=file.read(length);assert hashlib.sha256(raw).digest()==header[16:48];manifest=json.loads(raw);assert manifest['version']in [3,4,5]and manifest['document']['schemaVersion']==47
 return manifest,48+length
for ref,names in [('canvas-reference.png',['canvas-centered.png','canvas-redo.png','canvas-reopened.png']),('key-reference.png',['key-aligned.png','key-redo.png','key-reopened.png']),('script-reference.png',['script-aligned.png']),('canvas-before.png',['canvas-undo.png']),('key-before.png',['key-undo.png'])]:
 for path in root.rglob(ref):
  expected=Image.open(path).convert('RGBA');pixels=expected.tobytes();assert expected.getchannel('A').getextrema()[1]>0
  for name in names:
   actual=Image.open(path.with_name(name)).convert('RGBA');assert actual.size==expected.size and actual.tobytes()==pixels,name
  report['pixels'].append({'reference':str(path.relative_to(root)),'dimensions':expected.size,'rgbaSha256':sha(pixels),'equal':names})
for path in root.rglob('canvas-centered.luma'):
 after=project(path)[0]['document'];before=project(path.with_name('canvas-before.luma'))[0]['document'];configured=project(path.with_name('canvas-configured.luma'))[0]['document'];assert before==configured;assert after==dict(before,children=[dict(before['children'][0],x=135,y=90)])
 report['projects'].append({'path':str(path.relative_to(root)),'referenceChoiceDoesNotEdit':True,'onlyExpectedPositionsChanged':True})
for path in root.rglob('key-aligned.luma'):
 after=project(path)[0]['document'];before=project(path.with_name('key-before.luma'))[0]['document'];configured=project(path.with_name('key-configured.luma'))[0]['document'];assert before==configured;parent=before['children'][0];expected=dict(before,children=[dict(parent,children=[dict(parent['children'][0],x=57.5,y=-42.5)]),before['children'][1]]);assert after==expected and after['children'][1]['locked']
 report['projects'].append({'path':str(path.relative_to(root)),'referenceChoiceDoesNotEdit':True,'lockedKeyAndParentBasisExact':True,'onlyExpectedPositionsChanged':True})
report['sidebars']=[]
for name in ['canvas-sidebar.json','key-sidebar.json']:
 for path in root.rglob(name):
  metrics=json.loads(path.read_text());assert metrics['listHeight']>=147 and metrics['panelScrollHeight']<=metrics['panelHeight']+1 and metrics['actionsBottom']<=metrics['panelBottom']+1 and metrics['extraHeight']>=36
  report['sidebars'].append({'path':str(path.relative_to(root)),**metrics})
for path in root.rglob('canvas-scroll-focus.luma'):
 assert project(path)[0]['document']==project(path.with_name('canvas-centered.luma'))[0]['document']
 report['keyboardScrollDoesNotEdit']=True
large=list(root.rglob('alignment-50mp-png.png'))
if large:
 assert len(large)==1;path=large[0];expected=Image.open('tests/fixtures/raw/native-50mp.png').convert('RGBA');expected.paste((36,104,172,255),(4700,2300,5300,2700));assert expected.size==(10000,5000)
 for name in ['alignment-50mp-png.png','alignment-50mp-reopened.png']:
  actual=Image.open(path.with_name(name)).convert('RGBA');assert actual.size==expected.size;extrema=ImageChops.difference(expected,actual).getextrema();assert all(high==0 for low,high in extrema),extrema
 projectPath=path.with_name('alignment-50mp-project.luma');manifest,offset=project(projectPath);asset=next(asset for asset in manifest['assets']if 'raw'in asset);original=manifest['rawOriginals'][asset['raw']['originalIndex']];assert original['size']==100000672 and original['sha256']=='cfe25bed379735dfea685695e956838b284106e6527e6aff77e3901ef6ef9d85'
 with projectPath.open('rb')as file:
  file.seek(offset+original['offset']);digest=hashlib.sha256();remaining=original['size']
  while remaining:
   block=file.read(min(remaining,1048576));assert block;digest.update(block);remaining-=len(block)
 assert digest.hexdigest()==original['sha256'];report['large']={'pixelsPerOutput':50000000,'rgbaSamplesPerOutput':200000000,'outputs':2,'maximumError':0,'originalBytes':original['size'],'projectOriginalSha256':digest.hexdigest(),'position':[4700,2300],'rectangle':[600,400]}
report['textPixels']=[]
for reference,names in [('text-before.png',['text-move-undo.png','text-appearance-undo.png']),('text-distribution-reference.png',['text-distributed.png']),('text-flip-reference.png',['text-flipped.png','text-reopened.png','text-reflow-undo.png'])]:
 for path in root.rglob(reference):
  expected=Image.open(path).convert('RGBA');pixels=expected.tobytes();assert expected.getchannel('A').getextrema()[1]>0
  for name in names:
   actual=Image.open(path.with_name(name)).convert('RGBA');assert actual.size==expected.size and actual.tobytes()==pixels,name
  report['textPixels'].append({'reference':str(path.relative_to(root)),'dimensions':expected.size,'rgbaSha256':sha(pixels),'exact':names})
report['textProjects']=[]
for path in root.rglob('text-before.luma'):
 before=project(path)[0]['document'];assert len(before['children'])==3 and all(layer['width']==20 and layer['height']==20 for layer in before['children'])
 def changed(index,patch):return dict(before,children=[dict(layer,**patch)if i==index else layer for i,layer in enumerate(before['children'])])
 assert project(path.with_name('text-moved.luma'))[0]['document']==changed(1,{'x':41})
 assert project(path.with_name('text-appearance.luma'))[0]['document']==changed(1,{'name':'Edited frame','opacity':.5})
 assert project(path.with_name('text-distributed.luma'))[0]['document']==changed(1,{'x':75})
 flipped=dict(before,children=[dict(layer,x=170-layer['x'],transform={'a':-1,'b':0,'c':0,'d':1,'e':0,'f':0})for layer in before['children']]);assert project(path.with_name('text-flipped.luma'))[0]['document']==flipped
 measured=json.loads(path.with_name('text-measurement-reference.json').read_text());assert (measured['width'],measured['height'])!=(20,20)
 reflowed=dict(flipped,children=[dict(layer,**measured)if i==1 else layer for i,layer in enumerate(flipped['children'])]);assert project(path.with_name('text-reflowed.luma'))[0]['document']==reflowed
 report['textProjects'].append({'path':str(path.relative_to(root)),'allOrdinaryEditsPreserveAuthoredGeometry':True,'onlyRequestedPropertiesChange':True,'explicitSameTextReflow':measured})

assert report['pixels'] and report['projects'];Path(sys.argv[2]).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'pixelGroups':len(report['pixels']),'projectChecks':len(report['projects']),'textPixelGroups':len(report['textPixels']),'large':report.get('large')}))
