from pathlib import Path
import subprocess,json,sys
cases=[('paint5',5,'paint'),('text-shadow',64,'text-shadow'),('vector512',64,'vector512'),('vector-static',64,'vector-static')]
for mode,layers,fixture in cases:
 for variant,port in [('baseline',4188),('candidate',4189)]:
  label=variant+'-'+mode
  with Path('/tmp/canoli-drag-'+label+'.log').open('w')as log:
   result=subprocess.run(['node','--import','tsx','/tmp/canoli-drag-profile.mjs',label,'http://127.0.0.1:'+str(port),str(layers),fixture],stdout=log,stderr=subprocess.STDOUT)
  if result.returncode:print(label,'failed',result.returncode,flush=True);sys.exit(result.returncode)
  r=json.loads(Path('/tmp/canoli-drag-'+label+'.json').read_text());summary=[]
  for block in r['blocks']:
   t=sorted(f['ms']for f in block['frames']);assert len(t)==24;summary.append({'guides':block['enabled'],'p95':t[22],'longTasks':len(block['longTasks'])})
  print(label,json.dumps(summary),flush=True)
