import {createRequire} from 'node:module';
import {writeFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
const require=createRequire(join(process.cwd(),'package.json')), {chromium}=require('@playwright/test');
const corpus=[{id:'paths-20',paths:20,layers:1},{id:'paths-200',paths:200,layers:1},{id:'paths-1000',paths:1000,layers:1},{id:'paths-200-layers-64',paths:200,layers:64},{id:'curves-200',paths:200,layers:1,anchors:100}];
const cases=corpus.filter(f=>!process.env.CANOLI_VECTOR_CASES||process.env.CANOLI_VECTOR_CASES.split(',').includes(f.id));
const output=process.env.CANOLI_VECTOR_OUTPUT??'/tmp/canoli-vector-baseline';await mkdir(output,{recursive:true});
const browser=await chromium.launch({headless:true,executablePath:process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE});
const reports=[];
try {for(const fixture of cases){
 const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{
  await page.goto(process.env.CANOLI_VECTOR_URL??'http://127.0.0.1:4173/');if(await page.evaluate(()=>'luma'in window))throw new Error('Use normal release');
  const run=async source=>{await page.getByRole('button',{name:'Scripts (Mod+Shift+K)',exact:true}).click();await page.getByLabel('Script code',{exact:true}).fill(source);await page.getByRole('button',{name:'Run script',exact:true}).click();};
  await page.getByTestId('project-input').setInputFiles('/tmp/canoli-vector-fixtures/'+fixture.id+'.luma');
  await page.getByRole('button',{name:'Select Moving vectors',exact:true}).waitFor();await page.getByRole('button',{name:'Select Moving vectors',exact:true}).click();
  await page.getByRole('button',{name:'Fit canvas (Mod+0)',exact:true}).click();await page.waitForFunction(()=>!document.querySelector('footer .status-dot.working'));await page.getByRole('button',{name:process.env.CANOLI_VECTOR_TOOL==='pen'?'Vector pen (P)':'Move tool (V)',exact:true}).click();
  await page.evaluate(async()=>{await document.fonts.ready;await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));});
  const pixels=()=>page.locator('.canvas-wrap canvas').evaluate(c=>c.toDataURL()),before=await pixels();
  await page.evaluate(()=>{
   const state={start:0,first:0,last:0,x:0,seq:0,samples:[],tasks:[],points:[],fills:0,copies:0};window.vectorProbe=state;
   const p=CanvasRenderingContext2D.prototype,fill=p.fill,draw=p.drawImage,clear=p.clearRect,bitmap=window.createImageBitmap,tags=new WeakMap();
   p.fill=function(...args){const result=fill.apply(this,args);if(this.fillStyle==='#f01122'){const t=this.getTransform();tags.set(this.canvas,{x:t.a*20+t.c*20+t.e,y:t.b*20+t.d*20+t.f});state.fills++;}return result;};
   p.clearRect=function(...args){tags.delete(this.canvas);return clear.apply(this,args);};
   p.drawImage=function(...args){const result=draw.apply(this,args),point=tags.get(args[0]);if(point){const source=args[0];let sx=0,sy=0,sw=source.width,sh=source.height,dx=args[1],dy=args[2],dw=sw,dh=sh;if(args.length===5){dw=args[3];dh=args[4];}if(args.length===9){sx=args[1];sy=args[2];sw=args[3];sh=args[4];dx=args[5];dy=args[6];dw=args[7];dh=args[8];}if(point.x>=sx&&point.x<sx+sw&&point.y>=sy&&point.y<sy+sh){const t=this.getTransform(),x=(point.x-sx)*dw/sw+dx,y=(point.y-sy)*dh/sh,at={x:t.a*x+t.c*y+t.e,y:t.b*x+t.d*y+t.f};tags.set(this.canvas,at);state.copies++;if(state.start&&this.canvas.isConnected&&this.canvas.closest('.canvas-wrap')){const box=this.canvas.getBoundingClientRect(),wrap=document.querySelector('.canvas-wrap').getBoundingClientRect(),zoom=wrap.width/800,wanted={x:(wrap.left+(20+state.x)*zoom-box.left)*this.canvas.width/box.width,y:(wrap.top+20*zoom-box.top)*this.canvas.height/box.height};if(Math.abs(wanted.x-at.x)<.01&&Math.abs(wanted.y-at.y)<.01){state.last=performance.now();state.samples.push(state.last-state.start);state.points.push({x:state.x,at,wanted});state.start=0;}}}}return result;};
   window.createImageBitmap=async function(...args){const point=tags.get(args[0]),result=await bitmap.apply(this,args);if(point)tags.set(result,point);return result;};
   const capture=event=>{if(event.key==='ArrowRight'||event.key==='ArrowLeft'){state.start=performance.now();state.first||=state.start;state.x+=event.key==='ArrowRight'?1:-1;state.seq++;}};window.addEventListener('keydown',capture,true);
   const entries=list=>list.map(t=>({start:t.startTime,duration:t.duration}));const observer=new PerformanceObserver(list=>state.tasks.push(...entries(list.getEntries())));observer.observe({type:'longtask'});
   state.finish=()=>{state.tasks.push(...entries(observer.takeRecords()));observer.disconnect();window.removeEventListener('keydown',capture,true);p.fill=fill;p.drawImage=draw;p.clearRect=clear;window.createImageBitmap=bitmap;};
  });
  const cdp=(process.env.CANOLI_VECTOR_PROFILE==='1'||process.env.CANOLI_VECTOR_TRACE==='1')?await context.newCDPSession(page):null;if(cdp){if(process.env.CANOLI_VECTOR_TRACE==='1')await cdp.send('Tracing.start',{categories:'devtools.timeline,v8',transferMode:'ReturnAsStream'});await cdp.send('Profiler.enable');await cdp.send('Profiler.start');}
  for(let i=1;i<=20;i++){await page.keyboard.press('ArrowRight');await page.waitForFunction(n=>window.vectorProbe.samples.length===n,i,{timeout:30000});}
  if(cdp){const {profile}=await cdp.send('Profiler.stop');await writeFile(join(output,fixture.id+'-profile.json'),JSON.stringify(profile));if(process.env.CANOLI_VECTOR_TRACE==='1'){const finished=new Promise(resolve=>cdp.once('Tracing.tracingComplete',resolve));await cdp.send('Tracing.end');const {stream}=await finished;let trace='';for(;;){const chunk=await cdp.send('IO.read',{handle:stream});trace+=chunk.data;if(chunk.eof)break;}await cdp.send('IO.close',{handle:stream});await writeFile(join(output,fixture.id+'-trace.json'),trace);}await cdp.detach();}
  await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))));
  const report=await page.evaluate(()=>{const s=window.vectorProbe;s.finish();return{samples:s.samples,tasks:s.tasks,longTasks:s.tasks.filter(t=>t.start+t.duration>=s.first&&t.start<=s.last),points:s.points,fills:s.fills,copies:s.copies,x:s.x,backend:document.querySelector('footer')?.textContent,developerGlobal:'luma'in window};});
  report.changed=before!==await pixels();if(!report.changed||report.x!==20||report.samples.length!==20)throw new Error('Invalid movement');
  await run(`print('Vector final',document.selectedLayer.x,document.selectedLayer.paths.length);`);await page.getByLabel('Script output').filter({hasText:`Vector final 20 ${fixture.paths}`}).waitFor();await page.getByRole('button',{name:'Close scripts',exact:true}).click();
  for(let i=0;i<20;i++)await page.keyboard.press('Control+z');await page.waitForFunction(()=>!document.querySelector('footer .status-dot.working'));await page.waitForFunction(before=>document.querySelector('.canvas-wrap canvas')?.toDataURL()===before,before);report.undoExact=before===await pixels();if(!report.undoExact||errors.length)throw new Error('Undo or page errors '+JSON.stringify(errors));
  const sorted=[...report.samples].sort((a,b)=>a-b);Object.assign(report,{fixture:{...fixture,tool:process.env.CANOLI_VECTOR_TOOL??'move'},p95Ms:sorted[18],maxMs:sorted.at(-1)});reports.push(report);await writeFile(join(output,fixture.id+'.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({id:fixture.id,p95Ms:report.p95Ms,maxMs:report.maxMs,longTasks:report.longTasks}));
 }catch(error){console.error(fixture.id,error);console.error(await page.evaluate(()=>window.vectorProbe));console.error(await page.getByLabel('Script output').allTextContents());throw error;}finally{await context.close();}
}await writeFile(join(output,'report.json'),JSON.stringify({reports,browser:browser.version()},null,2));}finally{await browser.close();}
