from pathlib import Path
import subprocess,json,hashlib,zipfile,os,sys,shutil
ROOT=Path('/home/kestrel/projects/luma-editor')
BASE='62a5b778de3d4fa0fdb7e912131a8b47f7208535'
OUT=Path('/dev/shm/canoli-vector-working-cache-2026-10-26.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
changed=subprocess.check_output(['git','diff','--name-only',BASE],cwd=ROOT).decode().splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT).decode().splitlines()
new=[p for p in new if not p.startswith('docs/benchmarks/')]
files=changed+new
patch=subprocess.check_output(['git','diff','--binary',BASE,'--',*changed],cwd=ROOT)
for p in new:
    r=subprocess.run(['git','diff','--binary','--no-index','/dev/null',p],cwd=ROOT,capture_output=True)
    assert r.returncode==1,r.stderr
    patch+=r.stdout
reconstructed=Path('/dev/shm/canoli-vector-source-reconstruction');assert not reconstructed.exists();reconstructed.mkdir()
for p in changed:
    dest=reconstructed/p;dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(subprocess.check_output(['git','show',BASE+':'+p],cwd=ROOT))
patchFile=Path('/tmp/canoli-vector-final-source.patch');patchFile.write_bytes(patch)
subprocess.run(['git','apply','--check',str(patchFile)],cwd=reconstructed,check=True)
subprocess.run(['git','apply',str(patchFile)],cwd=reconstructed,check=True)
sourceHashes={p:sha((ROOT/p).read_bytes()) for p in files}
assert all(sha((reconstructed/p).read_bytes())==v for p,v in sourceHashes.items())
identities=json.loads(Path('/tmp/canoli-vector-final-freeze.json').read_text())
assert all(sha((ROOT/p).read_bytes())==v for p,v in identities.items())
summary={'baseCommit':BASE,'sourceFiles':sourceHashes,'sourceReconstructionExact':True,'frozenFilesVerified':len(identities),'reports':{}}
for mode,expected in [('native',150),('production',152)]:
    r=json.loads(Path(f'/tmp/canoli-vector-final-{mode}.json').read_text());tests=[]
    def walk(s):
        for spec in s.get('specs',[]):
            tests.extend(spec['tests'])
        for child in s.get('suites',[]):walk(child)
    for suite in r['suites']:walk(suite)
    assert len(tests)==expected and not r.get('errors')
    assert r['stats']['unexpected']==r['stats']['skipped']==r['stats']['flaky']==0
    assert all(t['status']=='expected' and len(t['results'])==1 and t['results'][0]['status']=='passed' for t in tests)
    summary['reports'][mode]={'cases':expected,'files':len(r['suites']),'attempts':expected,'failures':0,'skips':0,'retries':0,'durationMs':r['stats']['duration']}
Path('/tmp/canoli-vector-final-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
entries={}
def add(path,arc):
    if path.is_file():entries[arc]=path
def tree(path,arc):
    for p in path.rglob('*'):
        if p.is_file():add(p,arc+'/'+str(p.relative_to(path)))
for pattern in ['canoli-drag-*','canoli-vector-*']:
    for p in Path('/tmp').glob(pattern):
        if p.is_file():add(p,'raw/'+p.name)
for p in files:add(ROOT/p,'source/'+p)
add(ROOT/'tests/fixtures/raw/native-50mp.png','originals/native-50mp.png')
tree(Path('/dev/shm/canoli-drag-baseline-dist'),'release/baseline')
tree(ROOT/'dist','release/candidate')
for d in ['canoli-drag-native-pilot','canoli-drag-native-pilot2','canoli-drag-native-pilot3','canoli-vector-final-native','canoli-vector-final-production']:
    tree(Path('/dev/shm')/d,'browser/'+d)
manifest={arc:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for arc,p in sorted(entries.items())}
with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
    z.writestr('README.txt','F14 compact vector working/cache pixels, 2026-10-26.\nFinal source reconstructs exactly from '+BASE+' using raw/canoli-vector-final-source.patch.\nOnly final 150-native and 152-production reports are acceptance; pilots and earlier harness versions are diagnostic.\nUse verified-1..3 for 288 paced matching-pixel timings per variant, harnessVersion 3. Overlay samples are absent, so no overlay latency claim. No physical compositor, sustained 60fps, GPU/device-wide or full-roadmap claim.\nIndependent Pillow/container readers check full 50 MP exports, original bytes and complete dense workflows.\n')
    z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
    for arc,p in sorted(entries.items()):z.write(p,arc)
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    for arc,m in manifest.items():assert sha(z.read(arc))==m['sha256']
result={'archive':str(OUT),'entries':len(entries)+2,'bytes':OUT.stat().st_size,'sha256':sha(OUT.read_bytes()),'sourceFiles':len(files),'frozenFiles':len(identities),'reports':summary['reports']}
Path('/tmp/canoli-vector-archive-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
