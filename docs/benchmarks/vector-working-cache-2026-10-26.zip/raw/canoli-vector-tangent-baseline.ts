import {writeFileSync} from 'node:fs';
import {performance} from 'node:perf_hooks';
import {nativeVectorFootprint} from '/home/kestrel/projects/luma-editor/src/engine/native-vector-footprint.ts';
import type {VectorPathData} from '/home/kestrel/projects/luma-editor/src/core/drawing.ts';
const results=[];
for(const count of [128,256,512]){
 let reads=0;
 const point=()=>new Proxy({x:32,y:32},{get(t,k){if(k==='x'||k==='y')reads++;return Reflect.get(t,k);}});
 const points=Array.from({length:count},()=>({...point(),in:point(),out:point()}));
 // Count anchor coordinates as well as control coordinates, without changing geometry.
 const anchors=points.map(p=>new Proxy(p,{get(t,k){if(k==='x'||k==='y')reads++;return Reflect.get(t,k);}}));
 const path:VectorPathData={id:'duplicate-points',points:anchors,closed:true,fill:null,stroke:'#ff0000',strokeWidth:16,strokeJoin:'miter',strokeMiterLimit:12};
 reads=0;const started=performance.now(),bounds=nativeVectorFootprint({paths:[path]}),elapsed=performance.now()-started;
 results.push({count,coordinateReads:reads,elapsedMs:elapsed,bounds});
}
writeFileSync('/tmp/canoli-vector-tangent-baseline.json',JSON.stringify({source:'acee560',results},null,2)+'\n');console.log(JSON.stringify(results));
