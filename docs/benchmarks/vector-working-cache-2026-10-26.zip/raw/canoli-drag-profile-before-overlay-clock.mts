import {chromium} from '/home/kestrel/projects/luma-editor/node_modules/@playwright/test/index.mjs';
import {historyScript} from '/home/kestrel/projects/luma-editor/tests/helpers/history-inspector.ts';
import {writeFile} from 'node:fs/promises';
const label=process.argv[2]??'baseline',baseURL=process.argv[3]??'http://127.0.0.1:4188',layers=Number(process.argv[4]??64),profile=process.argv.includes('--profile'),mode=process.argv[5]??'paint';
const browser=await chromium.launch({executablePath:'/home/kestrel/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome',ignoreDefaultArgs:['--disable-dev-shm-usage']});
try{
 const page=await browser.newPage({viewport:{width:1440,height:1000}});await page.goto(baseURL);if(await page.evaluate(()=>'luma'in window))throw new Error('Expected normal production');
 const fixture=`document.resize(800,600);let target;for(let i=0;i<${layers};i++){
 const selected=i===${Math.min(27,layers-1)},placement={name:selected?'Measured target':'Reference '+i,x:40+i%8*70,y:30+Math.floor(i/8)*65};let layer;
 if('${mode}'.startsWith('vector')&&!selected||'${mode}'.startsWith('vector')&&selected&&'${mode}'!=='vector-static'){
  layer=new VectorLayer(placement);const paths=selected?${mode==='vector512'?512:200}:32;
  for(let j=0;j<paths;j++){const path=VectorPath.rectangle(j===0&&selected?{x:0,y:0,width:20,height:20}:{x:j%8*2,y:Math.floor(j/8)%8*2,width:3,height:3});path.stroke=null;path.fill=selected?'#ef3a2c':'#2468ac';layer.paths.add(path);}
 }else if('${mode}'.startsWith('text')){
  layer=new TextLayer({...placement,text:selected?'M':'Design '+i,fontSize:selected?20:16,lineHeight:1,color:selected?'#ef3a2c':'#2468ac'});
  if('${mode}'==='text-shadow')layer.styles=new LayerStyle({dropShadow:{enabled:true,blur:3,x:2,y:4,opacity:.5,color:'#362044'}});
 }else{layer=new PaintLayer(placement);layer.strokes.add(new PaintFill({bounds:{x:0,y:0,width:20,height:20},color:selected?'#ef3a2c':'#2468ac'}));}
 document.layers.add(layer);if(selected)target=layer;
 }document.selectedLayer=target;`;
 if(mode.startsWith('vector')){
  await historyScript(page,'document.resize(800,600);','Drag size ready');
  for(let start=0;start<layers;start+=8){const batch=fixture.replace('document.resize(800,600);','').replace(`let i=0;i<${layers};i++`,`let i=${start};i<${Math.min(start+8,layers)};i++`).replace('document.selectedLayer=target;','if(target)document.selectedLayer=target;');await historyScript(page,batch,'Drag batch ready '+start);}
  await historyScript(page,"for(const layer of document.layers)if(layer.name==='Measured target')document.selectedLayer=layer;",'Drag profile ready');
 }else await historyScript(page,fixture,'Drag profile ready');
 await page.keyboard.press('Control+1');await page.getByLabel('Spacing guides',{exact:true}).check();const box=(await page.locator('.canvas-wrap').boundingBox())!,index=Math.min(27,layers-1),x=40+index%8*70,y=30+Math.floor(index/8)*65;
 await page.getByTestId('artwork').waitFor();await page.waitForFunction(()=>!document.querySelector('footer .status-dot.working'));const backend=await page.getByTestId('artwork').getAttribute('data-renderer');if(backend!=='canvas2d')throw new Error('This probe requires observed Canvas2D; got '+backend);
 await page.evaluate(({box,x,y})=>{
  const state={box,x,y,sequence:0,eventTime:0,wantedX:x,wantedY:y,armed:false,frames:[]as any[],overlays:[]as any[],longTasks:[]as any[],presentCalls:0};(window as any).dragProbe=state;
  const initial=document.querySelector('[data-testid="artwork"]')as HTMLCanvasElement,c=initial.getContext('2d')!,r=initial.getBoundingClientRect(),px=Math.floor((box.x+x-8-r.left)*initial.width/r.width),py=Math.floor((box.y+y-8-r.top)*initial.height/r.height),image=c.getImageData(px,py,64,55).data;
  (state as any).reference=Array.from({length:64*55},(_,i)=>image[i*4]===239&&image[i*4+1]===58&&image[i*4+2]===44&&image[i*4+3]===255?1:0);if((state as any).reference.reduce((a:number,b:number)=>a+b,0)<4)throw new Error('Missing independent red frame marker');
  const originalOutline=document.querySelector('.selection-outline')as HTMLElement;(state as any).outlineX=parseFloat(originalOutline.style.left);(state as any).outlineY=parseFloat(originalOutline.style.top);
  const observer=new PerformanceObserver(list=>state.longTasks.push(...list.getEntries().map(e=>({start:e.startTime,duration:e.duration}))));observer.observe({entryTypes:['longtask']});(window as any).dragObserver=observer;
  window.addEventListener('pointermove',e=>{if(e.buttons!==1||!state.armed)return;state.eventTime=performance.now();state.sequence++;state.wantedX=x+Math.round(e.clientX-(box.x+x+10));state.wantedY=y+Math.round(e.clientY-(box.y+y+10));const seq=state.sequence;requestAnimationFrame(()=>{const outline=document.querySelector('.selection-outline')as HTMLElement;if(seq===state.sequence&&outline&&Math.abs(parseFloat(outline.style.left)-((state as any).outlineX+state.wantedX-x))<.001&&Math.abs(parseFloat(outline.style.top)-(state as any).outlineY-state.wantedY+y)<.001)state.overlays.push({sequence:seq,ms:performance.now()-state.eventTime});});},true);
  const draw=CanvasRenderingContext2D.prototype.drawImage;CanvasRenderingContext2D.prototype.drawImage=function(...args:any[]){
   const result=(draw as any).apply(this,args),canvas=this.canvas;if(canvas instanceof HTMLCanvasElement&&canvas.dataset.testid==='artwork'&&state.armed&&state.eventTime){
    state.presentCalls++;const now=performance.now(),rect=canvas.getBoundingClientRect(),px=Math.floor((state.box.x+x-8-rect.left)*canvas.width/rect.width),py=Math.floor((state.box.y+y-8-rect.top)*canvas.height/rect.height),pixels=this.getImageData(px,py,64,55).data,dx=state.wantedX-x,dy=state.wantedY-y;
    let matched=true,foreground=0;const reference=(state as any).reference;
    for(let row=0;row<55&&matched;row++)for(let col=0;col<64;col++){const index=row*64+col,rx=col-dx,ry=row-dy,expected=rx>=0&&rx<64&&ry>=0&&ry<55?reference[ry*64+rx]:0,actual=pixels[index*4]===239&&pixels[index*4+1]===58&&pixels[index*4+2]===44&&pixels[index*4+3]===255?1:0;if(actual)foreground++;if(expected!==actual){matched=false;break;}}
    (state as any).lastPresent={matched,foreground,dx,dy,width:canvas.width,height:canvas.height};
    if(matched){state.frames.push({sequence:state.sequence,submittedMs:now-state.eventTime,ms:performance.now()-state.eventTime,x:state.wantedX,y:state.wantedY,foreground});state.eventTime=0;}
   }return result;
  };
 },{box,x,y});
 const cdp=await page.context().newCDPSession(page);if(profile){await cdp.send('Profiler.enable');await cdp.send('Profiler.setSamplingInterval',{interval:100});await cdp.send('Profiler.start');}
 const blocks=[];
 for(const enabled of [false,true,true,false]){
  await page.getByLabel('Spacing guides',{exact:true}).setChecked(enabled);const current=(await page.locator('.canvas-wrap').boundingBox())!;
  await page.mouse.move(current.x+x+10,current.y+y+10);await page.mouse.down();await page.evaluate(box=>{const p=(window as any).dragProbe;p.box=box;p.armed=true;p.eventTime=0;p.frames=[];p.overlays=[];p.longTasks=[];p.presentCalls=0;},current);
  for(let i=0;i<24;i++){const dx=4+i%12,dy=i%3;const previous=await page.evaluate(()=>(window as any).dragProbe.sequence);await page.mouse.move(current.x+x+dx+10,current.y+y+dy+10);await page.waitForFunction(previous=>{const p=(window as any).dragProbe;return p.frames.some((f:any)=>f.sequence>previous);},previous,{timeout:5000}).catch(async error=>{await writeFile('/tmp/canoli-drag-'+label+'-failure.json',JSON.stringify(await page.evaluate(()=>(window as any).dragProbe),null,2));await page.screenshot({path:'/tmp/canoli-drag-'+label+'-failure.png'});throw error;});}
  blocks.push(await page.evaluate(enabled=>{const p=(window as any).dragProbe;p.armed=false;return{enabled,frames:p.frames,overlays:p.overlays,longTasks:p.longTasks,presentCalls:p.presentCalls};},enabled));await page.keyboard.press('Escape');await page.mouse.up();await page.waitForFunction(()=>!document.querySelector('footer .status-dot.working'));
 }
 if(profile){const result=await cdp.send('Profiler.stop');await writeFile('/tmp/canoli-drag-'+label+'-cpu.json',JSON.stringify(result.profile));}
 await historyScript(page,`if(document.selectedLayer.x!==${x}||document.selectedLayer.y!==${y})throw new Error('Cancelled drag changed artwork');print('Source preserved');`,'Drag source verified');
 await writeFile('/tmp/canoli-drag-'+label+'.json',JSON.stringify({label,layers,mode,fixture,backend,timingBoundary:"after matching pixel readback and verification; paced updates",normalProduction:true,runtime:{chromium:browser.version(),node:process.version},blocks,sourcePreserved:true},null,2));console.log(JSON.stringify({label,layers,mode,backend,blocks:blocks.map(b=>{const t=b.frames.map((f:any)=>f.ms).sort((a:number,b:number)=>a-b);return{guides:b.enabled,samples:t.length,median:t[Math.floor(t.length/2)],p95:t[Math.ceil(t.length*.95)-1],longTasks:b.longTasks};})}));
}finally{await browser.close();}
