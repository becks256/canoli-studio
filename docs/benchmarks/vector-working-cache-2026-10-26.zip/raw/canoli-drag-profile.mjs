import { chromium } from "/home/kestrel/projects/luma-editor/node_modules/@playwright/test/index.mjs";
import { historyScript, historyPng } from "/home/kestrel/projects/luma-editor/tests/helpers/history-inspector.ts";
import { writeFile } from "node:fs/promises";
const label = process.argv[2] ?? "baseline", baseURL = process.argv[3] ?? "http://127.0.0.1:4188", layers = Number(process.argv[4] ?? 64), profile = process.argv.includes("--profile"), mode = process.argv[5] ?? "paint";
const browser = await chromium.launch({ executablePath: "/home/kestrel/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome", ignoreDefaultArgs: ["--disable-dev-shm-usage"] });
try {
  const page = await browser.newPage({ viewport: { width: 1440, height: 1e3 } });
  await page.goto(baseURL);
  if (await page.evaluate(() => "luma" in window)) throw new Error("Expected normal production");
  const fixture = `document.resize(800,600);let target;for(let i=0;i<${layers};i++){
 const selected=i===${Math.min(27, layers - 1)},placement={name:selected?'Measured target':'Reference '+i,x:40+i%8*70,y:30+Math.floor(i/8)*65};let layer;
 if('${mode}'.startsWith('vector')&&!selected||'${mode}'.startsWith('vector')&&selected&&'${mode}'!=='vector-static'){
  layer=new VectorLayer(placement);const paths=selected?${mode === "vector512" ? 512 : 200}:32;
  for(let j=0;j<paths;j++){const path=VectorPath.rectangle(j===0&&selected?{x:0,y:0,width:20,height:20}:{x:j%8*2,y:Math.floor(j/8)%8*2,width:3,height:3});path.stroke=null;path.fill=selected?'#ef3a2c':'#2468ac';layer.paths.add(path);}
 }else if('${mode}'.startsWith('text')){
  layer=new TextLayer({...placement,text:selected?'M':'Design '+i,fontSize:selected?20:16,lineHeight:1,color:selected?'#ef3a2c':'#2468ac'});
  if('${mode}'==='text-shadow')layer.styles=new LayerStyle({dropShadow:{enabled:true,blur:3,x:2,y:4,opacity:.5,color:'#362044'}});
 }else{layer=new PaintLayer(placement);layer.strokes.add(new PaintFill({bounds:{x:0,y:0,width:20,height:20},color:selected?'#ef3a2c':'#2468ac'}));}
 document.layers.add(layer);if(selected)target=layer;
 }document.selectedLayer=target;`;
  if (mode.startsWith("vector")) {
    await historyScript(page, "document.resize(800,600);", "Drag size ready");
    for (let start = 0; start < layers; start += 8) {
      const batch = fixture.replace("document.resize(800,600);", "").replace(`let i=0;i<${layers};i++`, `let i=${start};i<${Math.min(start + 8, layers)};i++`).replace("document.selectedLayer=target;", "if(target)document.selectedLayer=target;");
      await historyScript(page, batch, "Drag batch ready " + start);
    }
    await historyScript(page, "for(const layer of document.layers)if(layer.name==='Measured target')document.selectedLayer=layer;", "Drag profile ready");
  } else await historyScript(page, fixture, "Drag profile ready");
  await page.keyboard.press("Control+1");
  await page.getByLabel("Spacing guides", { exact: true }).check();
  const box = await page.locator(".canvas-wrap").boundingBox(), index = Math.min(27, layers - 1), x = 40 + index % 8 * 70, y = 30 + Math.floor(index / 8) * 65;
  await page.getByTestId("artwork").waitFor();
  await page.waitForFunction(() => !document.querySelector("footer .status-dot.working"));
  const backend = await page.getByTestId("artwork").getAttribute("data-renderer");
  if (backend !== "canvas2d") throw new Error("This probe requires observed Canvas2D; got " + backend);
  await page.evaluate(({ box: box2, x: x2, y: y2 }) => {
    const state = { box: box2, x: x2, y: y2, sequence: 0, eventTime: 0, wantedX: x2, wantedY: y2, armed: false, frames: [], overlays: [], longTasks: [], presentCalls: 0 };
    window.dragProbe = state;
    const initial = document.querySelector('[data-testid="artwork"]'), c = initial.getContext("2d"), r = initial.getBoundingClientRect(), px = Math.floor((box2.x + x2 - 8 - r.left) * initial.width / r.width), py = Math.floor((box2.y + y2 - 8 - r.top) * initial.height / r.height), image = c.getImageData(px, py, 64, 55).data;
    state.reference = Array.from({ length: 64 * 55 }, (_, i) => image[i * 4] === 239 && image[i * 4 + 1] === 58 && image[i * 4 + 2] === 44 && image[i * 4 + 3] === 255 ? 1 : 0);
    if (state.reference.reduce((a, b) => a + b, 0) < 4) throw new Error("Missing independent red frame marker");
    const originalOutline = document.querySelector(".selection-outline");
    state.outlineX = parseFloat(originalOutline.style.left);
    state.outlineY = parseFloat(originalOutline.style.top);
    const observer = new PerformanceObserver((list) => state.longTasks.push(...list.getEntries().filter((e) => state.armed && e.startTime >= state.blockStart).map((e) => ({ start: e.startTime, duration: e.duration }))));
    observer.observe({ entryTypes: ["longtask"] });
    window.dragObserver = observer;
    window.addEventListener("pointermove", (e) => {
      if (e.buttons !== 1 || !state.armed) return;
      state.eventTime = performance.now();
      state.sequence++;
      state.wantedX = x2 + Math.round(e.clientX - (state.box.x + x2 + 10));
      state.wantedY = y2 + Math.round(e.clientY - (state.box.y + y2 + 10));
      const seq = state.sequence, started = state.eventTime;
      requestAnimationFrame(() => {
        const outline = document.querySelector(".selection-outline");
        if (seq === state.sequence && outline && Math.abs(parseFloat(outline.style.left) - (state.outlineX + state.wantedX - x2)) < 1e-3 && Math.abs(parseFloat(outline.style.top) - state.outlineY - state.wantedY + y2) < 1e-3) state.overlays.push({ sequence: seq, ms: performance.now() - started });
      });
    }, true);
    const draw = CanvasRenderingContext2D.prototype.drawImage;
    CanvasRenderingContext2D.prototype.drawImage = function(...args) {
      const result = draw.apply(this, args), canvas = this.canvas;
      if (canvas instanceof HTMLCanvasElement && canvas.dataset.testid === "artwork" && state.armed && state.eventTime) {
        state.presentCalls++;
        const now = performance.now(), rect = canvas.getBoundingClientRect(), px2 = Math.floor((state.box.x + x2 - 8 - rect.left) * canvas.width / rect.width), py2 = Math.floor((state.box.y + y2 - 8 - rect.top) * canvas.height / rect.height), pixels = this.getImageData(px2, py2, 64, 55).data, dx = state.wantedX - x2, dy = state.wantedY - y2;
        let matched = true, foreground = 0;
        const reference = state.reference;
        for (let row = 0; row < 55 && matched; row++) for (let col = 0; col < 64; col++) {
          const index2 = row * 64 + col, rx = col - dx, ry = row - dy, expected = rx >= 0 && rx < 64 && ry >= 0 && ry < 55 ? reference[ry * 64 + rx] : 0, actual = pixels[index2 * 4] === 239 && pixels[index2 * 4 + 1] === 58 && pixels[index2 * 4 + 2] === 44 && pixels[index2 * 4 + 3] === 255 ? 1 : 0;
          if (actual) foreground++;
          if (expected !== actual) {
            matched = false;
            break;
          }
        }
        state.lastPresent = { matched, foreground, dx, dy, width: canvas.width, height: canvas.height };
        if (matched) {
          state.frames.push({ sequence: state.sequence, submittedMs: now - state.eventTime, ms: performance.now() - state.eventTime, x: state.wantedX, y: state.wantedY, foreground });
          state.eventTime = 0;
        }
      }
      return result;
    };
  }, { box, x, y });
  const output = { outputPath: (name) => "/tmp/canoli-drag-" + label + "-" + name };
  await historyPng(page, output, "before.png");
  const cdp = await page.context().newCDPSession(page);
  if (profile) {
    await cdp.send("Profiler.enable");
    await cdp.send("Profiler.setSamplingInterval", { interval: 100 });
    await cdp.send("Profiler.start");
  }
  const blocks = [];
  for (const enabled of [false, true, true, false]) {
    await page.getByLabel("Spacing guides", { exact: true }).setChecked(enabled);
    const current = await page.locator(".canvas-wrap").boundingBox();
    await page.mouse.move(current.x + x + 10, current.y + y + 10);
    await page.mouse.down();
    await page.evaluate((box2) => {
      const p = window.dragProbe;
      p.box = box2;
      p.armed = true;
      p.eventTime = 0;
      p.frames = [];
      p.overlays = [];
      p.longTasks = [];
      p.presentCalls = 0;
      p.blockStart = performance.now();
    }, current);
    for (let i = 0; i < 24; i++) {
      const dx = 4 + i % 12, dy = i % 3;
      const previous = await page.evaluate(() => window.dragProbe.sequence);
      await page.mouse.move(current.x + x + dx + 10, current.y + y + dy + 10);
      await page.waitForFunction((previous2) => {
        const p = window.dragProbe;
        return p.frames.some((f) => f.sequence > previous2);
      }, previous, { timeout: 5e3 }).catch(async (error) => {
        await writeFile("/tmp/canoli-drag-" + label + "-failure.json", JSON.stringify(await page.evaluate(() => window.dragProbe), null, 2));
        await page.screenshot({ path: "/tmp/canoli-drag-" + label + "-failure.png" });
        throw error;
      });
    }
    blocks.push(await page.evaluate(async (enabled2) => {
      const p = window.dragProbe;
      await new Promise((resolve) => setTimeout(resolve, 0));
      const observer = window.dragObserver;
      p.longTasks.push(...observer.takeRecords().filter((e) => e.startTime >= p.blockStart).map((e) => ({ start: e.startTime, duration: e.duration })));
      p.armed = false;
      return { enabled: enabled2, blockStart: p.blockStart, blockEnd: performance.now(), frames: p.frames, overlays: p.overlays, longTasks: p.longTasks, presentCalls: p.presentCalls };
    }, enabled));
    await page.keyboard.press("Escape");
    await page.mouse.up();
    await page.waitForFunction(() => !document.querySelector("footer .status-dot.working"));
  }
  if (profile) {
    const result = await cdp.send("Profiler.stop");
    await writeFile("/tmp/canoli-drag-" + label + "-cpu.json", JSON.stringify(result.profile));
  }
  await historyScript(page, `if(document.selectedLayer.x!==${x}||document.selectedLayer.y!==${y})throw new Error('Cancelled drag changed artwork');print('Source preserved');`, "Drag source verified");
  await historyPng(page, output, "cancelled.png");
  await writeFile("/tmp/canoli-drag-" + label + ".json", JSON.stringify({ label, layers, mode, fixture, backend, harnessVersion: 3, timingBoundary: "after matching pixel readback and verification; paced updates", overlayBoundary: "rAF after matching DOM coordinates; independent captured clock", normalProduction: true, runtime: { chromium: browser.version(), node: process.version }, blocks, sourcePreserved: true }, null, 2));
  console.log(JSON.stringify({ label, layers, mode, backend, blocks: blocks.map((b) => {
    const t = b.frames.map((f) => f.ms).sort((a, b2) => a - b2);
    return { guides: b.enabled, samples: t.length, median: t[Math.floor(t.length / 2)], p95: t[Math.ceil(t.length * 0.95) - 1], longTasks: b.longTasks };
  }) }));
} finally {
  await browser.close();
}
