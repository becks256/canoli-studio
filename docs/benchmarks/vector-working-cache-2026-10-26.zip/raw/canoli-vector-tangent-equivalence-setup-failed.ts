import {nativeVectorFootprint as before} from './canoli-vector-tangent-control.ts';
import {nativeVectorFootprint as after} from '/home/kestrel/projects/luma-editor/src/engine/native-vector-footprint.ts';
import {createHash} from 'node:crypto';
import {writeFileSync} from 'node:fs';
import {deepStrictEqual} from 'node:assert';
import type {PathAnchor,VectorPathData} from '/home/kestrel/projects/luma-editor/src/core/drawing.ts';
let seed=0x51a7c0de;const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/2**32),choose=<T>(a:T[])=>a[Math.floor(random()*a.length)],hash=createHash('sha256');
const anchor=(x:number,y:number,curve:boolean):PathAnchor=>({x,y,in:{x:x+(curve?(random()-.5)*64:0),y:y+(curve?(random()-.5)*64:0)},out:{x:x+(curve?(random()-.5)*64:0),y:y+(curve?(random()-.5)*64:0)}});
let cases=0;const kinds:Record<string,number>={};
for(let i=0;i<5000;i++){
 const kind=i%10,closed=i%2===0,count=1+Math.floor(random()*80),scale=choose([1,1,1,2**-24,2**30]),origin=choose([0,0,2**45,-2**45]),points:PathAnchor[]=[];
 for(let j=0;j<count;j++){
  if(j>0&&(kind===0||random()<.65))points.push(structuredClone(points[j-1]));
  else points.push(anchor(origin+Math.floor((random()-.5)*512)*scale,origin+Math.floor((random()-.5)*512)*scale,kind%3===0));
 }
 if(kind===1&&count>2){points[0]=anchor(0,0,false);points[1]=anchor(1000,0,false);points[2]=anchor(0,.00000001,false);}
 if(kind===2&&count>2){points[0]=anchor(0,0,false);points[1]=anchor(1000,0,false);points[2]=anchor(0,0,false);}
 const path:VectorPathData={id:'case-'+i,points,closed,fill:choose(['#ffffff',null]),stroke:kind===9?null:'#ff0000',strokeWidth:choose([0,1,16,200]),strokeJoin:choose(['miter','miter','miter','round','bevel']),strokeCap:choose(['butt','square','round']),strokeMiterLimit:choose([1,2,4,12,2**20,Number.MAX_SAFE_INTEGER])};
 if(i%4===0)path.subpaths=[{id:'sub-'+i,points:structuredClone(points).reverse(),closed:true}];
 const value={paths:[path]},snapshot=JSON.stringify(value),old=before(value),next=after(value);deepStrictEqual(next,old,'case '+i);deepStrictEqual(JSON.stringify(value),snapshot,'input '+i);hash.update(JSON.stringify({value,bounds:next})+'\n');cases++;kinds[String(kind)]=(kinds[String(kind)]??0)+1;
}
const result={seed:'0x51a7c0de',cases,exact:true,inputsUnchanged:true,kinds,corpusAndOutputSha256:hash.digest('hex')};writeFileSync('/tmp/canoli-vector-tangent-equivalence.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
