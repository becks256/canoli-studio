from pathlib import Path
from collections import Counter
import hashlib,json,re,datetime
root=Path('/home/kestrel/projects/luma-editor')
def digest(path):
 p=Path(path);return {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
unit=Path('/tmp/canoli-vector-gradients-unit-final.log').read_text();browser=Path('/tmp/canoli-vector-gradients-browser-final.log').read_text();production=Path('/tmp/canoli-vector-gradients-production-final.log').read_text()
assert re.search(r'Tests\s+999 passed',unit)
assert re.search(r'Test Files\s+134 passed',unit)
assert re.search(r'353 passed',browser),browser[-1000:]
assert re.search(r'37 passed',production),production[-1000:]
assert not re.search(r'\d+ failed',browser+production)
counts=dict(Counter(re.findall(r'✓\s+\d+ (tests/[^:]+):',browser)));assert sum(counts.values())==353
assert counts['tests/vector-gradients.e2e.ts']==30
assert counts['tests/webgpu.e2e.ts']==18
assert '✓ built' in Path('/tmp/canoli-vector-gradients-build-final.log').read_text()
assert re.search(r'Tests\s+5 passed',Path('/tmp/canoli-vector-gradients-seo-final.log').read_text())
assert Path('/tmp/canoli-vector-gradients-types-final.log').read_text()==''
assert Path('/tmp/canoli-vector-gradients-diff-final.log').read_text()==''
nativeModes=['linear','alpha','hard-stops','radial','focal','two-circle','outside-focal','radial-transform','paint-transform','layer-affine','reset']
importModes=['bbox-curve','bbox-cubic','bbox-radial','user-percent','reference-alpha','template-color','stop-default','stop-inherit','template-interpolation','css-transparent','css-alpha-low','css-modern-alpha','current-color','clamped-stops','compound']
names=[f'canoli-vector-gradient-{m}.json' for m in nativeModes]+[f'canoli-vector-gradient-import-{m}.json' for m in importModes]+[f'canoli-vector-gradient-{m}.json' for m in ['ui','50mp','composition','css-fallback','gpu','production']]
reports={name:json.loads((Path('/tmp')/name).read_text()) for name in names}
native=[reports[f'canoli-vector-gradient-{m}.json'] for m in nativeModes];imports=[reports[f'canoli-vector-gradient-import-{m}.json'] for m in importModes]
assert all(r['reopened'] and r['editable'] and r['roundtripExact'] for r in native)
assert all(r['reopened'] and r['editable'] for r in imports)
assert all(r['svg']['interior']<=2 for r in native)
assert all(r['interior']<=2 for r in imports)
historical={name:json.loads((Path('/tmp')/name).read_text()) for name in ['canoli-vector-gradients-initial-reports.json','canoli-vector-gradient-css-alpha-before.json','canoli-vector-gradients-inheritance-initial-reports.json']}
sourceFiles=['package.json','package-lock.json','src/core/vector-gradient.ts','src/core/vector-stroke.ts','src/core/bezier-bounds.ts','src/core/svg-gradient-import.ts','src/core/drawing.ts','src/core/model.ts','src/core/commands.ts','src/core/validation.ts','src/core/store.ts','src/core/shapes.ts','src/core/affine.ts','src/core/transform-schema.ts','src/core/svg-import.ts','src/core/svg-path-import.ts','src/core/svg-path.ts','src/core/svg-export.ts','src/core/svg-masks.ts','src/core/svg-smart.ts','src/core/svg-styles.ts','src/core/svg-composition.ts','src/core/project.ts','src/core/image-resize.ts','src/core/crop.ts','src/dom/index.ts','src/editor.ts','src/tools.ts','src/engine/drawing.ts','src/engine/renderer.ts','src/engine/cache.ts','src/engine/gpu/renderer.ts','src/engine/export.ts','src/engine/png.ts','src/engine/svg-import.ts','src/engine/svg-import.worker.ts','src/ui/VectorGradientControls.tsx','src/ui/VectorStrokeControls.tsx','src/ui/ToolOptions.tsx','src/ui/InspectorPanel.tsx','src/ui/controls.tsx','src/ui/styles.css','src/scripting/runtime.ts','src/generated/script-runtime.js','src/ai/recipes/recorder.ts','server/app.ts','assembly/pixels.ts','public/wasm/pixels.wasm','README.md','docs/PRODUCT_BRIEF.md','docs/REQUIREMENTS.md','docs/ARCHITECTURE.md','docs/API.md','docs/SCRIPTING_API.md','docs/DESIGN_SYSTEM.md','docs/PLUGINS.md','docs/SYSTEM_DESIGN.md','docs/STORAGE_FORMAT.md','docs/FEATURE_STRATEGY.md','docs/IMPLEMENTATION_ROADMAP.md','tests/vector-gradients.test.ts','tests/vector-gradients.e2e.ts','tests/vector-strokes.test.ts','tests/vector-strokes.e2e.ts','tests/api.test.ts','tests/webgpu.e2e.ts','tests/production.e2e.ts','tests/seo.test.ts','tests/chromatic-adjustments.e2e.ts','tests/gradient-map.e2e.ts','tests/affine-render.e2e.ts','tests/svg-import-pixels.ts','playwright.config.ts','playwright.production.config.ts']
sourceFiles += [str(p.relative_to(root)) for p in sorted(root.glob('tests/svg-*.e2e.ts')) if str(p.relative_to(root)) not in sourceFiles]
sourceFiles += ['node_modules/@xmldom/xmldom/'+p for p in ['package.json','lib/dom-parser.js','lib/sax.js','lib/dom.js']]
sourceDuringRun=json.loads(Path('/tmp/canoli-vector-gradients-final-run-source-hashes.json').read_text())
for name,sha in sourceDuringRun.items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha,name
prior=json.loads(Path('/tmp/canoli-vector-gradients-prior-evidence.json').read_text())
for name,record in prior.items():assert digest(root/name)==record,name
logs={}
for p in sorted(Path('/tmp').glob('canoli-vector-gradients-*.log')):logs[str(p)]={**digest(p),'tail':p.read_text(errors='replace').splitlines()[-15:]}
proof=json.loads(Path('/tmp/canoli-vector-gradients-docs-runtime-proof.json').read_text());assert proof['allHashIdentical']
record={
 'schemaVersion':1,'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'T16/F07/F11 editable linear/radial vector fill paint and inert SVG gradient import/export; full professional-editor roadmap remains active and incomplete',
 'versions':{'document':23,'projectContainer':3,'workspaceSnapshot':2},
 'implementation':{
  'nativePaint':'Optional nullable path.fillGradient value overrides retained solid fill; linear endpoints or radial start/end circles, 2-32 nondecreasing hex/opacity stops with hard transitions, and optional independent invertible affine paint transform',
  'validation':'Strict finite coordinate/radius/stop/opacity/transform validation and defensive input/output ownership; OO constructors/factories/attached setters and shared commands/history/locks/revision checks; separate headless REST conformance',
  'migration':'Valid v1-v22 documents/history upgrade without injecting paint; earlier labels containing fillGradient reject outside the immutable validation cache; original sources/project/workspace formats unchanged',
  'rendering':'Trace geometry under world placement, then fill with world*paint transform active; restore state before subsequent stroke/path. Existing GPU reference uploads/cache keys retain paint. Native tile origins cannot reset gradients',
  'ui':'Native Solid/Linear/Radial selector, color/position/opacity stops, live opacity Slider and precise numeric value, preview Escape cancellation, insertion including coincident stops, removal/reversal, local geometry and disclosed affine matrix fields; shared undo/locks',
  'svgExport':'Validated editable paint servers with user-space coordinates, ordered opacity stops, full matrix, encoded-sRGB interpolation and document-scoped generated IDs',
  'svgImport':'Inert local template geometry, supported numeric/object-box/user-space/viewport lengths, actual cubic extrema excluding stroke, normalized SVG stop offsets, own interpolation property and explicit non-inherited stop-property computation in the chosen definition tree',
  'cssStops':'Preserve unpremultiplied RGB at zero/low alpha using native relative sRGB conversion and canonical RGB/sRGB fallback; out-of-sRGB/unrepresentable colors require explicit flattening',
  'sourceIsolation':'No source image mutation, MP/file-size import cutoff, new service/provider, install-time execution, plugin grant, isolated file/network/asset-byte privilege or REST/browser synchronization',
  'recipes':'Existing layer-add templates retain paint values; standalone path-update recording remains explicitly unsupported',
 },
 'verification':{
  'build':{'command':'npm run build','result':'actual WASM/runtime/developer-doc generation, TypeScript and production bundling passed'},
  'unit':{'command':'npm test -- --maxWorkers=2','passed':999,'files':134,'newGradientInvariantCases':9,'newRestCases':1},
  'development':{'command':'npx playwright test tests/svg- tests/vector-strokes.e2e.ts tests/vector-gradients.e2e.ts tests/webgpu.e2e.ts tests/affine-render.e2e.ts tests/editor.e2e.ts tests/adjustments.e2e.ts tests/gradient-map.e2e.ts tests/chromatic-adjustments.e2e.ts tests/recipes.e2e.ts tests/foundation-increments.e2e.ts tests/tools.e2e.ts tests/vector-construction-latency.e2e.ts','passed':353,'casesByFile':counts,'newGradientFileCases':30,'softwareGpuFileCases':18},
  'production':{'command':'npm run test:production','passed':37,'newCase':'Verbatim documented constructor example through isolated Scripts, real inspector and SVG/PNG downloads, independent color samples, one edit undo plus whole-script undo, and editable SVG reimport; no developer globals'},
  'seo':{'command':'npx vitest run tests/seo.test.ts','passed':5},'typecheck':'npx tsc -b passed','gitDiffCheck':'passed','selectedDistinctBrowserCases':390,
 },
 'nativeComparisons':{'fixtures':len(native),'svgByteExactModes':[r['mode'] for r in native if r['svg']['alpha']==0 and r['svg']['premult']==0],'maxCanvasAlpha':max(r['canvas']['alpha'] for r in native),'maxCanvasPremult':max(r['canvas']['premult'] for r in native),'maxSvgAlpha':max(r['svg']['alpha'] for r in native),'maxSvgPremult':max(r['svg']['premult'] for r in native),'allNativePngAfterSvgReimportExact':all(r['roundtripExact'] for r in native),'allProjectJsonReopensExact':all(r['reopened'] for r in native)},
 'importComparisons':{'fixtures':len(imports),'maxAlpha':max(r['alpha'] for r in imports),'maxPremult':max(r['premult'] for r in imports),'maxOpaqueInteriorPremult':max(r['interior'] for r in imports),'maxAreaError':max(r['areaError'] for r in imports),'maxCentroidErrorPx':max(r['centroidError'] for r in imports),'method':'Retain raw alpha/premultiplied residuals. Require direct interior color agreement; require whole-image premultiplied maxima <=2 for rectangular fixtures. Curved path antialiasing uses independent interior, silhouette, area and centroid checks; not universal pixel equality.'},
 'observations50MP':reports['canoli-vector-gradient-50mp.json'],
 'limitations':[
  'Full F07/F11 and the overall roadmap remain incomplete. Boolean/richer vector/type/brush/color/RAW/AI/workflow/commercial/specialist requirements and broader interchange/device/performance gates remain.',
  'Only encoded 8-bit sRGB stop colors and pad spread are native. Repeat/reflect, gradient strokes, linearRGB interpolation, out-of-sRGB/HDR/unavailable CSS conversion, degenerate rejected native geometry and unsupported CSS/paint graphs require explicit flattening.',
  'Absolute-unit object-box lengths and viewport gradient percentages with an offset viewBox remain explicit flatten cases. XML/template identity and dynamic/shared definitions are not archived; converted object-box coordinates are native local values.',
  'Template colors follow the tested Chromium definition tree; SVG2 shadow-style inheritance may differ in other viewers. Two-circle/outside-focal radial behavior depends on viewer SVG2 support. Actual old browsers and hardware GPU presentation remain unverified.',
  'Curved/affine/mask edges retain raw raster differences. Direct interior color, silhouette and source geometry checks constrain errors without claiming universal viewer pixel identity or a browser-internal cause.',
  'Relative-color absence is emulated by a real Canvas setter override with restoration; this is not actual legacy-browser acceptance. Software GPU reads premultiplied RGBA8; Canvas/PNG is straight RGBA8.',
  '50 MP elapsed time is a single local observation, not p95/input-to-photon/long-task/peak-memory/device speed or controlled speedup evidence. Native output uses bounded tiles; resident source bitmaps and viewer PNG decode still consume substantial memory.',
  'Standalone path-update recipe recording and wider mask/style graph reimport remain explicitly unsupported; native/project mask composition is verified separately.',
 ],
 'validationStages':[
  'Initial focused unit test used exact floating-point equality for a quadratic extremum (49.99999999999999 vs 50); corrected to a tight numeric bound without rounding geometry. Final analytical cubic two-root/ID-collision checks are included.',
  'Initial browser run: 12/16 passed. Actual paint-transform restoration lost linear gradient coordinates; the fill now runs with paint transform active. Old geometry-only residual checks were too loose for radial color fields, so direct interior and whole-image premultiplied gates were added.',
  'Corrected initial 16 browser cases passed; expanded radial/focal/CSS/preview/crop/mask/GPU coverage afterward. A Slider numeric-label test locator was updated to its actual accessible value name, and preview values now follow the live command without committing artwork.',
  'A TypeScript mask fixture called an unimplemented ellipse factory; corrected to the actual MarqueeSelection constructor before runtime verification.',
  'An earlier 345-case broad run was deliberately stopped for an actual CSS transparent-stop RGB bug; it had 86 passes, two stale schema-22 assertion failures, one interrupted and 256 unrun. Those two expected-version assertions now match current schema 23. This is not counted as final coverage.',
  'Read-only browser proof showed source center [126,0,128,128] vs incorrect native [0,0,128,128] for transparent red CSS stop. Fixed unpremultiplied conversion and verified exact visible pixels, low/modern alpha and canonical fallback; unrepresentable gamut rejects before publication.',
  'Initial stop/template inheritance fixtures: two passed/two failed. Corrected non-inherited stop defaults and separated own CSS interpolation from template geometry; all eight color/inheritance cases passed. Case-insensitive/whitespace CSS keywords are covered in final unit/browser cases.',
  'Final 999 unit/API, full selected development, complete production, build/typecheck/SEO and whitespace checks pass. Source and runtime hashes are retained; no roadmap completion claim.',
 ],
 'primaryReferences':['https://www.w3.org/TR/SVG2/pservers.html','https://www.w3.org/TR/SVG/latest/pservers.html','https://html.spec.whatwg.org/multipage/canvas.html#fill-and-stroke-styles'],
 'environment':json.loads(Path('/tmp/canoli-vector-gradients-environment.json').read_text()),
 'priorEvidenceUnchanged':prior,'proseOnlyRefreshRuntimeProof':proof,
 'sourceHashes':{name:digest(root/name) for name in sourceFiles},
 'sourceHashesDuringFinalBrowserRun':sourceDuringRun,
 'builtHashes':{str(p.relative_to(root)):digest(p) for p in sorted((root/'dist').rglob('*')) if p.is_file()},
 'reports':reports,'historicalDiagnostics':historical,'logs':logs,
}
out=root/'docs/benchmarks/vector-gradients-2026-10-16.json';assert not out.exists(),'Prior evidence already sealed; do not overwrite.'
out.write_text(json.dumps(record,indent=2)+'\n');print(out,len(record['sourceHashes']),'source hashes',len(record['builtHashes']),'built hashes',len(reports),'reports')
