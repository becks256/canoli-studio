Photoshop pixel clipping verification, 2026-10-26.

manifest.json maps logical paths to byte sizes and SHA-256 hashes. Each unique
payload is stored as objects/<sha256>. To restore all verified logical files:
  python3 extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY

source/ contains every changed source, test, fixture and document. Apply
raw/final-source.patch to baseCommit from manifest.json for reconstruction.
raw/ retains accepted and failed/interrupted reports, strict independent
recomposition diagnostics, frozen-input hashes and redundant-temp restoration
mappings. browser/ retains the actual output artifacts and release/ contains
the tested production resources. Interpret accepted runs using their final
JSON statistics. The full stable native run passed 236/237; its remaining
stale Canvas reference passes a separate corrected 36-comparison run with
unchanged tolerances and product inputs. The interrupted earlier native run
is not complete acceptance.

Independent RGB8 reader checks disable ICC conversion. The 50 MP check uses
pointwise exact binary coverage and complete sample comparisons; it does not
force full-float recomposition or establish desktop/color/device/memory parity.
The initial soft-base mismatch was corrected without widening tolerances by
normalizing exported coverage into an editable pixel mask. Incoming soft raw
base alpha retains explicit merged fallback. Original native projects remain
the complete authoring/source-preservation format.
