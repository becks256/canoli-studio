from pathlib import Path
import sys,json,hashlib,zipfile
archive=Path(sys.argv[1]);root=Path(sys.argv[2]).resolve();root.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(archive) as z:
 manifest=json.loads(z.read('manifest.json'))
 for name,meta in manifest['files'].items():
  target=(root/name).resolve()
  if not target.is_relative_to(root):raise ValueError('Unsafe evidence path')
  payload=z.read('objects/'+meta['sha256'])
  assert len(payload)==meta['bytes']and hashlib.sha256(payload).hexdigest()==meta['sha256']
  if target.exists():
   assert target.is_file()and hashlib.sha256(target.read_bytes()).hexdigest()==meta['sha256'],str(target)
  else:
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(payload)
 print('Restored and verified',len(manifest['files']),'logical evidence files')
