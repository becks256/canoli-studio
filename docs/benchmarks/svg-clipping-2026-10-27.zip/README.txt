Editable SVG geometric clipping verification, 2026-10-27.

manifest.json maps logical paths to byte sizes and SHA-256 hashes. Each unique
payload is stored as objects/<sha256>. To restore all verified logical files:
  python3 extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY

source/ contains every changed source, test, fixture and document. Apply
raw/final-source.patch to baseCommit from manifest.json for reconstruction.
raw/ retains accepted and failed reports, independent coordinate probes,
frozen-input hashes and verified restoration of older temporary originals.
browser/ retains actual output artifacts; release/ contains tested production
resources. See final-audit.json and the dated roadmap for observed acceptance.

Native SVG decoding is independent of the Canoli importer. Axis-aligned
integer fixtures require exact RGBA. Fractional, affine, curved and text
fixtures retain the existing area, centroid, interior and contour checks;
Canvas and SVG clipping edge sampling are not claimed universally identical.
Every supported small fixture also requires exact native-project output and
exact native PNG output after editable SVG round-trip. The genuine 50 MP
fixture retains complete original source bytes and independently compares all
200,000,000 RGBA samples in each masked/released/reopened/round-tripped output.
No tolerance was widened after failures. Pilots preserve coordinate and fixture
corrections and the generated smart-viewport alpha-sampling regression. The
first full native matrix passed 397/399; the final full native and production
runs must be interpreted using their separate complete JSON statistics.
The full original professional-editor roadmap remains active.

The nested older-temp-backup.zip and temp-compression.json retain complete
older temporary originals released for disk headroom, with verified byte and
hash restoration mapping. Primary historical evidence was not altered.
