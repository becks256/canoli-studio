Connected ICC application workflow, 2026-10-27.

manifest.json maps logical paths to exact byte sizes and SHA-256 hashes.
Unique payloads are objects/<sha256>. Restore using:
  python3 extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY
source/ and raw/final-source.patch reconstruct exact changes against baseCommit.
raw/ retains build/typecheck/unit/browser/audit reports, including failed pilots.
browser/ retains actual UI workflows, native 50 MP files, independent decoder
results and source/history/workspace checks. release/ is the verified build.

The earlier dependency archive contains native build/reference provenance.
This archive extends it with real browser proofing, profile ownership and
converted RGB8 output, including transparent samples and complete original
embedded profiles. Independent Pillow/Little CMS and MuPDF inspect files
without editor decoders. The final audit distinguishes the 87 source tests
before reviewed profile-picker/proof-failure retry fixes from focused source checks and
the complete final production matrix after that correction. No physical color,
60fps, high precision, CMYK delivery, HDR, working-space assignment/conversion,
portable job dependencies or complete-roadmap acceptance is claimed.
