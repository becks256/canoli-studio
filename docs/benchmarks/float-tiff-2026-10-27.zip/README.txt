Normalized SDR float TIFF input verification, 2026-10-27.

manifest.json maps logical paths to byte sizes/SHA256; unique payloads live
at objects/<sha256>. extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY restores
logical paths. source/ and raw/final-source.patch reconstruct every changed
file against baseCommit. raw/ retains actual build/unit/browser results,
failed/aborted initial pilots, source/release identities and final audit.
reference/ retains independent libtiff/native Little CMS fixtures, source
samples, profiles, generator provenance, Linux libraries and licenses.
browser/ contains UI original/choice retention, layout/color/alpha comparison,
real 50 MP import/save/reopen/export, malformed/HDR rejection, active/queued
cancellation, workspace/history/recipe/copy/recovery/brush-source regressions,
and JS-disabled 390px guide checks. release/ is the frozen production build
with 37 developer guides.

The original cross-endian libtiff 4.3.0 predictor writer diagnostic is retained.
Corrected source generation compensates writer input only and verifies native
float readback. No decoder exception or widened tolerance hides wrong input.
Small source samples and proxies compare exactly to an independent native CMM;
the real 10000x5000 P3 float source retains complete original bytes and all
200,000,000 exported RGBA8 samples compare exactly to the native reference.
The initial runtime pilot exposed a real dynamic JSON import/MIME failure;
that code snapshot and failed reports remain. Static JSON importing corrects
both Vite dev and the production bundle. Final gates use frozen inputs.
After those accepted gates, one terminal LF is removed from each of two test
files. Retained accepted snapshots and exact comparisons prove this cleanup
changes only whitespace. Runtime and complete release bytes stay unchanged.

Current editing remains sRGB8 and every float import requires explicit consent.
Unprofiled input requires an explicit sRGB/linear-sRGB interpretation. Numeric
HDR/nonfinite/invalid alpha and known ICC CICP PQ/HLG sources reject without
partial document publication. Complete original float samples/profiles and
choices remain authoritative across existing native/workspace/recipe/recovery
and brush transports; color diagnostics are rederived.

This does not implement working spaces, float scene/compositing/effects,
HDR tone mapping/reconstruction, CMYK, physical photographic/device quality,
independent REST rendering/jobs, sustained editor-wide performance or the
complete original roadmap. The original goal remains active.
