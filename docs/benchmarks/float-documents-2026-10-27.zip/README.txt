Initial connected float document workflow, 2026-10-27.

manifest.json maps logical paths to byte lengths/SHA256; unique bytes live in
objects/. extract-evidence.py restores logical paths. Every payload is verified.
source/ plus raw/final-source.patch reconstruct changed files against baseCommit.
release/ is the exact complete corrected production build, including 40 guides.
initial-release/ preserves the first frozen build before proof snapshot review.
pre-admission-release/ preserves the full 189-source/164-production accepted
build before the final retained-project source-role correction. Both source
versions and exact frozen identities are retained separately.
raw/ includes build/unit/browser/full-production reports, source/release pins,
failed and interrupted pilots, independently reproduced proof/queued cancellation
bugs, original type errors and fixture corrections, resource relocation receipt,
served-byte audit and the final observed acceptance record.
browser/ includes real output files, original-bearing projects, independent
sample comparisons, screenshots, and before/after lifecycle regressions.
reference/ contains complete original/profile/native-library bytes, independent
libtiff/Linux CMM references, generator fingerprints/provenance and licenses.

The actual 10000x5000 editor document imports an original float TIFF without a
native-sized byte editing proxy, retains native geometry, applies real linear
exposure and delivers true float32/uint16 TIFF. Independent native readers check
all 200000000 channel samples per file, complete ICC, exact words and sample
hashes. Small originals also deliver directly converted PNG/PDF with independent
native CMM/Pillow/MuPDF readback. Twelve source layouts and eight native TIFF
orientations retain exact native color/alpha. Group/interpolation checks declare
the independent arithmetic bound before running and retain both sample hashes.
Scripts/inert plugins, strict host source roles, ordinary Undo, native projects,
workspace originals, portable recipes and partial precise batch retry share the
real model/validation boundary. Accepted output cannot acquire a byte checkpoint.
Compiled production source workers retain all twelve independent original hashes;
the ordinary production import/script/Undo/export/reopen workflow uses no globals.

This is an initial scene subset. Normal/pass-through groups, masks and exposure
are supported; broader profiles, precision formats, tools/layers/blends/styles/
clipping/coverage/proof/HDR/CMYK/interchange remain required. Source buffers are
bounded independently of geometry; display/thumbnail quantization is explicit.
No arbitrary original resolution cap, paid call, account, upload or isolated
file/native/network grant is introduced. REST sessions remain independent of the
browser. No sustained 60fps, physical device/photographic quality or whole-process
peak-memory claim follows from the numerical and lifecycle checks. The complete
original roadmap goal stays active. See the dated roadmap and final-audit.json
for exact observed counts, failed/passing boundaries and remaining scope.
