Native ICC engine dependency verification, 2026-10-27.

manifest.json maps logical paths to byte sizes and SHA-256 hashes. Every unique
payload is objects/<sha256>. Restore all logical files with:
  python3 extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY

source/ and raw/final-source.patch reconstruct exact changed source against
baseCommit. raw/ includes actual failed and accepted reports, complete original
reader-version reference files, native compiler/source identities, an independent
native CMM library/control, the initial strict-admission implementation, source
fingerprints and the verified unchanged production-resource identities. browser/
contains real worker and JavaScript-disabled guide artifacts. release/ contains
the current application build. This is not application ICC feature acceptance.

The native dependency is not wired into the production app yet. All 45 prior
application JS/WASM/CSS/font resources remain exact. Developer pages and the
new copied MIT license are additional/current documentation. No new full
application production matrix is claimed. The 50 focused cases are included
in the full 2461-unit/API run; two actual worker browser cases and one built
guide case are separately recorded. All actual 23 browser color windows have
zero RGB and alpha error against their stated references. Old CMM 2.16 and
pinned 2.19.1 black-point heuristics differ on the coarse synthetic v2 CMYK
perceptual/BPC case. Preserve both; the pinned-version independent native
reference is exact, and no threshold was widened. Synthetic devices do not
prove physical color quality. Higher precision, CMYK/HDR output, application
integration, transport and full roadmap acceptance remain required.
