F02 clipping masks, 2026-10-26.
Exact source reconstructs from 9342a04e7efffd0bce56bf500e631e5d8e74bea1 with raw/canoli-clipping-final-source.patch.
Only final 192-native/153-production reports are full acceptance; diagnostic/pilot failures are retained.
Direct Path2D and canonical native rasterization differed by one alpha step. Final clipping references use original authored native coverage and retain zero-error assertions. No tolerance was relaxed.
Source MIME, TypeScript fixtures and primary-navigation assumptions were corrected; the original full JSON report failed during disk exhaustion. Only regeneratable old Node cache and verified sealed temporary duplicates were reclaimed.
Schema 48; unchanged project/workspace containers, cache budgets, grants, original resolution and source bytes. SVG/PSD/PSB prefixes bake clipping with explicit loss reports. Advanced Photoshop clipping/import parity, sustained/editor-wide/device/GPU performance and the full roadmap remain open.

Content-addressed ZIP: manifest.json maps every original logical path to its complete bytes and SHA-256; objects/<sha256> stores each unique payload once.
Extract extract-evidence.py and run: python3 extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY
The restored raw/canoli-clipping-final-source.patch reconstructs all final changed source files from the base commit recorded above.
