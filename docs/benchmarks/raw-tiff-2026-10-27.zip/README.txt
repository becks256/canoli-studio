Native RAW TIFF delivery verification, 2026-10-27.

manifest.json maps logical paths to byte sizes/SHA256; unique payloads live
at objects/<sha256>. extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY restores
logical paths. source/ and raw/final-source.patch reconstruct every changed
file against baseCommit. raw/ retains actual build/unit/type/browser results,
failed test-only diagnostics, source/release identities and the final audit.
reference/ retains complete independent sensor/RGB16 fixtures, profiles,
native Linux Little CMS, system libtiff, compiler/source/build provenance.
browser/ contains actual normal UI, retained master, cancellation/binary retry,
integer/float TIFF downloads, independent native file comparisons, original-
bearing legacy regression projects and the JS-disabled 390px guide. release/
is the frozen production build with 36 developer guides.

Every sample in both genuine 50 MP files is checked through libtiff native
sample reads against direct native Linux Little CMS over dcraw_emu RGB16.
Each file has 200,000,000 RGBA samples, with exact color/alpha/profile matches
in this environment. The source retains 223/152/306 distinct channel values;
no 8-bit canvas or working PNG enters native master delivery. Small native
unit checks additionally cover manual NumPy lens equations, exact calibrated
region assembly, malformed/oversized/nonfinite tiles and shared owner limits.

This does not implement document working spaces or high-precision scene
compositing/effects/import/persistence/editing, general float TIFF input,
HDR reconstruction, CMYK, independent REST rendering/jobs, full photographic
breadth, physical camera/print quality, measured device/resource/sustained
performance or the full original roadmap. Float encoding from 16-bit native
development does not create more sensor detail. The full goal stays active.
