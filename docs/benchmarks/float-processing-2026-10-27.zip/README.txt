Native float processing dependency verification, 2026-10-27.

manifest.json maps logical paths to byte sizes/SHA256; unique payloads live
at objects/<sha256>. extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY restores
logical paths. source/ and raw/final-source.patch reconstruct every changed
file against baseCommit. raw/ retains final build/unit/browser reports,
initial private payload type errors, source/release identities, native ABI
reflection, full production discovery and the final audit. reference/ retains
independent NumPy samples/outputs, float TIFF sensor-derived originals, complete
ICC sources, native Linux Little CMS/system libtiff/provenance and licenses.
Prior pixel WASM supports independent old/new function-signature checking.
release/ is the complete frozen build with 38 developer guides.

browser/ retains actual source and full-production artifacts, including all 18
float blend-mode and affine references, byte/mask/brush/wet/frequency/GPU/RAW/
TIFF/ICC regressions, original-bearing projects, real files, 390px JavaScript-
disabled guide and true float processing output. The verification-only pipeline
streams original TIFF float samples through actual native source ICC to linear
float32, native affine gain/offset and masked normal source-over, and real
float32 TIFF with complete linear ICC. It never stages an 8-bit canvas/PNG.
The independent native libtiff/Linux CMM/NumPy reader compares all output samples
and records actual/reference raw-float hashes, color/alpha error, bit differences
and extended RGB counts. The genuine 10000x5000 workflow checks 200000000 samples.

Other than the two added pixel exports, all 34 previous native function signatures
are retained. RAW/lens/CMM binaries stay unchanged. Native float scratch uses
65536-pixel windows; internal wire requests cap working windows at 262144 pixels,
independently of full original/document geometry. Owned inputs, private transfers,
exact typed replies and alpha/finite validation preserve existing byte owners.

This is a required precision-processing dependency and a verification prototype,
not public float editing. Current documents/rendering/history remain sRGB8.
Owned float source/tile storage, versioned working-space/precision OO commands,
actual compositor/effect/mask/tool/cache/display, original-bearing native/history/
workspace/recovery, precision scene/batch output, wider HDR blending/tone mapping/
reconstruction/CMYK and scoped automation remain required. Physical quality,
device/resource/sustained editor-wide performance and the entire original
professional/AI/workflow/collaboration/commercial/specialist roadmap remain open.
The original goal stays active; exact synthetic pixels do not establish those gates.
