ICC precision dependency verification, 2026-10-27.

manifest.json maps logical names to exact sizes/SHA256; unique payloads are
objects/<sha256>. extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY restores
logical paths. source/ and raw/final-source.patch reconstruct changed files
against baseCommit. raw/ retains actual failed and accepted diagnostics,
compiled build, source/release identities and the final audit. reference/
retains independent Linux Little CMS, native compiler/source provenance,
complete profiles and the unchanged genuine 50 MP linear RGB16 source.
source/tests/fixtures/icc-precision contains independent expected samples and
complete generators. browser/ records actual worker and unchanged connected
UI paths, cancellation and all-sample 50 MP conversion. release/ is the checked
production build. The actual output digest covers all 400,000,000 RGBA16 bytes;
it is a root over 500 sequential 100,000-pixel window SHA256 values.

No 8-bit proxy is used by the new native transforms. The 50 MP source has
223/152/306 distinct R/G/B values; the independent smaller identity ramp
separately proves 4,096-level integer preservation and float samples prove
sub-byte and extended linear precision. Synthetic sources/profiles do not
prove calibrated physical quality. This dependency does not implement a
working-space document model or high-precision scene, compositing, editing,
import/persistence/output, high-precision proof, CMYK/HDR, independent REST
rendering/jobs, device/resource/performance acceptance or the entire roadmap.
