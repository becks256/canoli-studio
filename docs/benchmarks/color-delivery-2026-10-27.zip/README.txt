Profile-aware batch and recipe delivery verification, 2026-10-27.

manifest.json maps logical paths to sizes/SHA-256; unique payloads live at
objects/<sha256>. Restore using extract-evidence.py ARCHIVE.zip OUTPUT_DIRECTORY.
source/ and raw/final-source.patch reconstruct every changed source against
baseCommit. raw/ retains failed pilots and final build/typecheck/unit/browser
reports, a frozen source/build manifest and final audit. browser/ contains
actual normal-UI/reload/package results, independent decoded files, full original
profiles, real 50 MP output, partial retry, corruption/cancellation/disposal
and legacy upgrade gates. release/ is the checked production build.

The earlier ICC engine/application archives retain native/compiler/reference
provenance. This increment adds complete profile dependency ownership through
native fitted batch PNG/TIFF/PDF, portable delivery presets and recipe packages.
It records actual conversion receipts, checks output settings on retry/package
and prevents older database clients from processing unsupported contracts.
Independent Pillow/Little CMS and MuPDF check every stored native sample.
This does not prove physical print quality, high precision, CMYK/HDR delivery,
working-space assignment/conversion, independent REST color rendering/jobs,
arbitrary artboards, universal memory/performance or full-roadmap completion.
