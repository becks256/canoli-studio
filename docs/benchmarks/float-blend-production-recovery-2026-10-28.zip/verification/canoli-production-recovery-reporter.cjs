const fs=require('node:fs');
module.exports=class RecoveryReporter{
 constructor(){this.path=process.env.CANOLI_RECOVERY_LOG;this.fd=fs.openSync(this.path,'wx');}
 write(row){fs.writeSync(this.fd,JSON.stringify({at:new Date().toISOString(),...row})+'\n');fs.fsyncSync(this.fd);}
 onBegin(config,suite){this.write({event:'begin',cases:suite.allTests().length,workers:config.workers});}
 onTestEnd(test,result){this.write({event:'test',id:test.id,title:test.titlePath(),expected:test.expectedStatus,status:result.status,retry:result.retry,duration:result.duration,errors:result.errors,attachments:result.attachments.map(({name,path,contentType})=>({name,path,contentType}))});}
 onError(error){this.write({event:'error',error});}
 onEnd(result){this.write({event:'end',...result});}
 onExit(){this.write({event:'exit'});fs.closeSync(this.fd);}
};
