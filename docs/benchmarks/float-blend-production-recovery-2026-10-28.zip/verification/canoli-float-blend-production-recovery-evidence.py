from pathlib import Path
import json,hashlib,zipfile,subprocess,os
root=Path('/home/kestrel/projects/luma-editor');run=Path('/run/lock/canoli-float-blend-production-recovery-2026-10-28');out=root/'docs/benchmarks/float-blend-production-recovery-2026-10-28.zip'
sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git',*args],cwd=root)
audit=json.loads(Path('/tmp/canoli-float-blend-production-recovery-audit.json').read_text());assert audit['status']=='passed'and audit['productionFullRunConfirmed']and audit['incrementalCasesExact']==172
assert git('rev-parse','HEAD').decode().strip()=='628ef531918a87086433a298fa316cf90f7aca2f'
prior=root/'docs/benchmarks/float-blend-2026-10-27.zip';prior_hash=sha(prior.read_bytes());assert prior_hash=='e5446a23569e7e8e63b9bb7e98e14bed14d59a21c1ec56e549a4eeb86009b02b'
manifest={'version':1,'baseline':audit['baseline'],'description':'Complete fresh production run closes the missing report for unchanged float-blend source/generated/release bytes. Original lost report is not reconstructed or relabeled. Full original roadmap remains active.','priorEvidence':{'path':str(prior.relative_to(root)),'sha256':prior_hash},'files':{}}
assert not out.exists()
with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=5)as z:
 def add(logical,path):
  assert path.is_file()and not path.is_symlink(),path
  data=path.read_bytes();assert logical not in manifest['files'];manifest['files'][logical]={'bytes':len(data),'sha256':sha(data)};z.writestr(logical,data)
 for p in sorted(run.rglob('*')):
  if p.is_file():add('production/'+str(p.relative_to(run)),p)
 for name in ['canoli-float-blend-production-recovery-audit.py','canoli-float-blend-production-recovery-audit.json','canoli-float-blend-production-recovery-audit.log','canoli-float-blend-production-recovery-audit.stderr','canoli-float-blend-production-recovery-evidence.py','canoli-float-blend-production-recovery.sh','canoli-production-recovery-reporter.cjs','canoli-float-blend-production-report-gap.json','canoli-float-blend-production-final.json','canoli-float-blend-production-final.stderr','canoli-float-blend-frozen.json','canoli-font-axes-production.config.ts']:
  add('verification/'+name,Path('/tmp')/name)
 add('original-gap/passed-marker.json',Path('/dev/shm/canoli-font-axes-runtime/float-blend-production-final/.last-run.json'))
 frozen=json.loads(Path('/tmp/canoli-float-blend-frozen.json').read_text())
 for rel,h in frozen['generated'].items():assert sha((root/rel).read_bytes())==h;add('generated/'+rel,root/rel)
 for rel,h in frozen['release'].items():assert sha((root/'dist'/rel).read_bytes())==h;add('release/'+rel,root/'dist'/rel)
 add('source/docs/IMPLEMENTATION_ROADMAP.md',root/'docs/IMPLEMENTATION_ROADMAP.md')
 z.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with out.open('rb')as handle:os.fsync(handle.fileno())
with zipfile.ZipFile(out)as z:
 m=json.loads(z.read('manifest.json'));assert len(z.namelist())==len(m['files'])+1
 for logical,identity in m['files'].items():
  data=z.read(logical);assert len(data)==identity['bytes']and sha(data)==identity['sha256'],logical
receipt={'archive':str(out.relative_to(root)),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'logicalFiles':len(manifest['files']),'baseline':manifest['baseline']};Path('/tmp/canoli-float-blend-production-recovery-sealed.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
