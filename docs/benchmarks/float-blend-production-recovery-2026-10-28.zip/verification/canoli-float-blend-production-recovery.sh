set -u
export NODE_DISABLE_COMPILE_CACHE=1
export TMPDIR=/run/lock/canoli-uint16-browser-runtime
export PLAYWRIGHT_CHROMIUM_EXECUTABLE=/home/kestrel/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome
export CANOLI_PDF_PYTHON=/tmp/canoli-pdf-check/bin/python
export CANOLI_PSB_PYTHON=/tmp/canoli-psb-check/bin/python
export CANOLI_AVIF_PYTHON=/tmp/canoli-avif-check/bin/python
export PLAYWRIGHT_JSON_OUTPUT_FILE=/run/lock/canoli-float-blend-production-recovery-2026-10-28/report.json
export CANOLI_RECOVERY_LOG=/run/lock/canoli-float-blend-production-recovery-2026-10-28/results.jsonl
node node_modules/@playwright/test/cli.js test --config /tmp/canoli-font-axes-production.config.ts --output /run/lock/canoli-float-blend-production-recovery-2026-10-28/artifacts --reporter=json,/tmp/canoli-production-recovery-reporter.cjs > /run/lock/canoli-float-blend-production-recovery-2026-10-28/stdout.log 2> /run/lock/canoli-float-blend-production-recovery-2026-10-28/stderr.log
canoli_recovery_exit=$?
python3 - "$canoli_recovery_exit" <<'PY'
from pathlib import Path
import json,sys,datetime
p=Path('/run/lock/canoli-float-blend-production-recovery-2026-10-28/terminal.json');p.write_text(json.dumps({'exitCode':int(sys.argv[1]),'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
PY
exit "$canoli_recovery_exit"
