from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/home/kestrel/projects/luma-editor');ram=Path('/dev/shm/canoli-font-axes-runtime');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def tests(suites):
 for suite in suites:
  for spec in suite.get('specs',[]):
   for test in spec.get('tests',[]):yield(spec['file'],spec['title'],test.get('projectName','')),test
  yield from tests(suite.get('suites',[]))
def one(matrix,name):
 folder=Path('/run/lock/canoli-float-blend-production-recovery-2026-10-28/artifacts')if matrix=='production-final'else ram/('float-blend-'+matrix);matches=list(folder.rglob(name));assert len(matches)==1,(matrix,name,matches);return matches[0]
def file_exact(path,row):assert path.stat().st_size==row['outputBytes']and sha(path)==row['outputSha256'],path
reports={};source_cases=set()
for name,count in [('browser-final',100),('native-50mp',2),('production-final',172),('integration-rebuilt',15),('large-retry',1)]:
 d=json.loads((Path('/run/lock/canoli-float-blend-production-recovery-2026-10-28/report.json')if name=='production-final'else Path('/tmp/canoli-float-blend-'+name+'.json')).read_text());s=d['stats'];assert s['expected']==count and all(s[k]==0 for k in ['skipped','unexpected','flaky'])and not d.get('errors'),s
 rows=list(tests(d['suites']));assert len(rows)==count
 for key,test in rows:
  assert test['status']=='expected'and len(test['results'])==1 and test['results'][0]['status']=='passed',test
  if name in ['native-50mp','large-retry']:assert test['results'][0]['duration']<=600000,test
  if name in ['browser-final','native-50mp','large-retry']:source_cases.add(key)
 reports[name]=s
assert len(source_cases)==103
unit=Path('/tmp/canoli-float-blend-unit-final.log').read_text();assert re.search(r'Test Files\s+282 passed \(282\)',unit)and re.search(r'Tests\s+2732 passed \(2732\)',unit)
build=Path('/tmp/canoli-float-blend-build-final.log').read_text();assert 'Built 40 developer documentation pages.'in build and 'built in'in build
frozen=json.loads(Path('/tmp/canoli-float-blend-frozen.json').read_text());listed=set(subprocess.check_output(['git','ls-files'],cwd=root).decode().splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root).decode().splitlines());inputs={p for p in listed if(root/p).is_file()and not p.startswith('docs/benchmarks/')and p!='docs/IMPLEMENTATION_ROADMAP.md'};assert inputs==set(frozen['inputs'])
for group in ['inputs','generated']:
 for path,h in frozen[group].items():assert sha(root/path)==h,path
release={str(p.relative_to(root/'dist')):sha(p)for p in(root/'dist').rglob('*')if p.is_file()};assert release==frozen['release'];assert len(release)==142
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()=='628ef531918a87086433a298fa316cf90f7aca2f'
wasm=subprocess.check_output(['git','ls-files','*.wasm'],cwd=root).decode().splitlines();assert len(wasm)==4
for path in wasm:assert(root/path).read_bytes()==subprocess.check_output(['git','show','HEAD:'+path],cwd=root)
assert sha(root/'public/wasm/pixels.wasm')==release['wasm/pixels.wasm']=='a1f55fcf95aa552d6e2c0a231d4ea57cceed971e2073a17b4ad285d9f549a8b3'
manifest=json.loads((root/'tests/fixtures/float-blend/manifest.json').read_text());scene_report=json.loads(one('browser-final','float-blend-scenes.json').read_text());assert len(scene_report)==108
for row,expected in zip(scene_report,manifest['cases']):
 assert row['context']==expected['context']and row['mode']==expected['mode']and row['actualSha256']==row['referenceSha256']==expected['rawSha256']and row['color']==row['alpha']==row['different']==row['partitionDifferent']==0 and row['modelUnchanged'],row
 assert row['halfNativeFirstVerified']==(row['context']=='raster')
assert sum(r['halfNativeFirstVerified']for r in scene_report)==18
ui=[]
for matrix in ['browser-final','production-final']:
 path=one(matrix,'float-blend-ui.json');d=json.loads(path.read_text());assert d['production']==(matrix=='production-final')and d['modes']==manifest['modes']and not d['errors']and all(d[k]for k in ['undoRedo','reopenedExact','originalExact']);assert len(d['frames'])==len(d['independent'])==18
 for mode,frame,row in zip(manifest['modes'],d['frames'],d['independent']):
  assert frame['mode']==row['mode']==mode and frame['different']==frame['maximum']==0 and row['samplesCompared']==131*79*4 and row['nonidenticalWords']==row['maximumError']==0 and row['completeProfileExact']and row['actualSampleSha256']==row['referenceSampleSha256'];file_exact(path.with_name('float-blend-ui-'+mode+'.tif'),row)
 domain=json.loads(one(matrix,'float-blend-domain-ui.json').read_text());assert domain['production']==(matrix=='production-final')and not domain['errors']and all(domain[k]for k in ['staleArtworkHidden','failureDisclosed','normalRecovered','undoRedo','modelRestored','originalExact'])
 ui.append({'matrix':matrix,'modes':len(d['modes']),'exactNativeFiles':len(d['independent']),'failureRecovery':domain})
isolated=json.loads(one('browser-final','float-blend-isolation.json').read_text());assert isolated['states']==manifest['modes']and all(isolated[k]for k in ['inert','applied','undo','unchanged','originalExact'])and isolated['permission']and isolated['atomicError']
example=json.loads(one('browser-final','float-blend-example.json').read_text());assert example['modes']==['normal','screen','color']and example['hash']==example['reopenedHash']and all(example[k]for k in ['undo','redo','modelExact','originalExact'])
batch_path=one('browser-final','float-blend-portable-batch.json');batch=json.loads(batch_path.read_text());assert batch['recordedPrecision']and batch['firstStatus']=='failed'and batch['accepted']==1 and batch['status']=='completed'and batch['checkpointPrecision']==batch['preparedPrecision']=='float32'and batch['preparedMode']=='hue'and batch['capturesOnRetry']==1 and all(batch[k]for k in ['acceptedUnchanged','preparedOriginalExact','activeUnchanged'])and len(batch['independent'])==2
for row in batch['independent']:
 assert row['samplesCompared']==131*79*4 and row['nonidenticalWords']==row['maximumError']==0 and row['completeProfileExact']and row['actualSampleSha256']==row['referenceSampleSha256'];file_exact(batch_path.with_name('float-blend-batch-'+row['precision']+'.tif'),row)
native=[]
for name in ['large-retry']:
 path=one(name,'float-blend-50mp.json');d=json.loads(path.read_text());assert d['dimensions']==[10000,5000]and all(d[k]for k in ['originalExact','restored','undo','redo'])and d['originalHash']==sha(root/'tests/fixtures/uint16-float/u16-native-50mp.tif')and d['layers']==manifest['largeLayers']and len(d['independent'])==2
 for row in d['independent']:
  assert row['samplesCompared']==200000000 and row['completeProfileExact']and row['maximumAlphaError']==row['alphaTolerance']==0 and row['maximumColorError']<=row['colorTolerance']==manifest['largeColorTolerance'][row['precision']];file_exact(path.with_name('float-blend-50mp-'+row['precision']+'.tif'),row)
 native.append({'matrix':name,'outputs':d['independent']})
for filename in ['float-transfer-50mp-float32.json','float-transfer-50mp-uint16.json']:
 path=one('native-50mp',filename);d=json.loads(path.read_text());assert d['dimensions']==[10000,5000]and all(d[k]for k in ['originalExact','restored','undo','redo'])and d['adjustments']==2 and len(d['independent'])==2
 old=list((ram/'float-frame-native-50mp').rglob(filename));assert len(old)==1;before=json.loads(old[0].read_text())
 for row,prior in zip(d['independent'],before['independent']):
  assert row['samplesCompared']==200000000 and row['nonidenticalWords']==row['maximumError']==0 and row['completeProfileExact']and row['actualSampleSha256']==row['referenceSampleSha256'];assert all(row[k]==prior[k]for k in ['precision','outputBytes','outputSha256','actualSampleSha256']);file_exact(path.with_name(path.stem+'-'+row['precision']+'.tif'),row)
 native.append({'matrix':'native-50mp','report':filename,'outputs':d['independent']})
# Retain prior native-first frame and continuous-transfer workflow acceptance.
for matrix in ['browser-final','production-final']:
 d=json.loads(one(matrix,'float-frame-ui.json').read_text());assert d['production']==(matrix=='production-final')and not d['errors']and all(d[k]for k in ['modelUnchanged','reopenedExact','originalExact'])and all(r['different']==r['maximum']==0 for r in d['rows'])
 path=one(matrix,'float-transfer-ui.json');d=json.loads(path.read_text());assert d['production']==(matrix=='production-final')and not d['errors']and all(d[k]for k in ['previewCancelled','levelsUndoRedo','curvesUndo','palette','linearHistogram','reopenedExact','originalExact'])and len(d['independent'])==4
 for kind,row in zip(['float32','uint16','png','pdf'],d['independent']):
  assert row['samplesCompared']==262144 and row['nonidenticalWords']==row['maximumError']==0 and row['completeProfileExact']and row['actualSampleSha256']==row['referenceSampleSha256'];file_exact(path.with_name('float-transfer-ui-'+kind+('.tif'if kind in ['float32','uint16']else'.'+kind)),row)
subprocess.check_call(['git','diff','--check'],cwd=root)
result={'status':'passed','baseline':'628ef531918a87086433a298fa316cf90f7aca2f','unitTests':2732,'unitFiles':282,'reports':reports,'sourceBrowserDistinct':103,'sourceInputsExact':len(frozen['inputs']),'generatedFilesExact':len(frozen['generated']),'releaseResourcesExact':len(release),'unchangedNativeCodecs':wasm,'unchangedPixelsWasmSha256':release['wasm/pixels.wasm'],'independentScenes':108,'independentNativeFirstHalfFrames':18,'normalNativeFilesUnchanged':True,'ui':ui,'nativeFiles':native,'postFreezeCorrections':[],'limitations':'Normalized artistic RGB only; broader float tools/working spaces/HDR/proof/CMYK/interchange, physical quality, peak memory, sustained editor-wide performance and all unfinished original roadmap gates remain required.'}

base=Path('/run/lock/canoli-float-blend-production-recovery-2026-10-28');terminal=json.loads((base/'terminal.json').read_text());assert terminal['exitCode']==0
ledger=[json.loads(line)for line in(base/'results.jsonl').read_text().splitlines()];assert ledger[0]['event']=='begin'and ledger[0]['cases']==172 and ledger[-1]['event']=='exit';assert not any(r['event']=='error'for r in ledger)
entries=[r for r in ledger if r['event']=='test'];assert len(entries)==172 and len({r['id']for r in entries})==172 and all(r['status']==r['expected']=='passed'and r['retry']==0 and not r['errors']for r in entries)
assert len([r for r in ledger if r['event']=='end'and r['status']=='passed'])==1
result['productionCliExitCode']=terminal['exitCode'];result['incrementalCasesExact']=len(entries);result['productionFullRunConfirmed']=True

Path('/tmp/canoli-float-blend-production-recovery-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
